import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Volume2, ArrowRight, CheckCircle, FileCheck, FileText } from 'lucide-react';

export default function ExamPortalPage() {
  const navigate = useNavigate();

  // Sub-view within this page: 'list', 'pdf-viewer', or 'exam-active'
  const [subView, setSubView] = useState('list');

  // Teacher Uploaded PDFs with parsed individual questions
  const [teacherUploadedPdfs] = useState([
    {
      id: 101,
      title: 'BCA_Sem6_Web_Tech_Question_Paper.pdf',
      subject: 'Web Development',
      uploadedBy: 'Prof. Sharma',
      date: 'Sep 21, 2026',
      questions: [
        'Section A: Answer all questions.',
        'Question 1: Explain the role of Mongoose in Node.js applications.',
        'Question 2: What are React hooks and how do they simplify state management?'
      ]
    },
    {
      id: 102,
      title: 'Database_Management_Midterm_Notes.pdf',
      subject: 'Database Management',
      uploadedBy: 'Prof. Anderson',
      date: 'Sep 20, 2026',
      questions: [
        'Introduction: Database Indexing overview.',
        'Question 1: Why are indexes used to quickly locate and access data without searching every row?',
        'Question 2: Describe the performance trade-offs when adding multiple indexes to a large collection.'
      ]
    }
  ]);

  const [activeTeacherPdf, setActiveTeacherPdf] = useState(null);
  const [pdfQuestionIndex, setPdfQuestionIndex] = useState(0);

  // Available Exams
  const [availableExams] = useState([
    {
      id: 1,
      title: 'Web Development Midterm',
      subject: 'Computer Science',
      duration: '30 mins',
      questions: [
        {
          id: 1,
          questionText: 'What is the primary function of CSS in web development?',
          options: ['Styling web pages', 'Managing database', 'Server routing', 'Compiling code'],
          correct: 0
        },
        {
          id: 2,
          questionText: 'Which tag is used for the largest heading in HTML?',
          options: ['<h6>', '<h1>', '<head>', '<heading>'],
          correct: 1
        }
      ]
    },
    {
      id: 2,
      title: 'Database Management Quiz',
      subject: 'BCA Sem 6',
      duration: '20 mins',
      questions: [
        {
          id: 1,
          questionText: 'Which of the following is a NoSQL document-oriented database?',
          options: ['MySQL', 'PostgreSQL', 'MongoDB', 'Oracle'],
          correct: 2
        },
        {
          id: 2,
          questionText: 'What ODM library is commonly used with Node.js to model MongoDB data?',
          options: ['Mongoose', 'Sequelize', 'Hibernate', 'Prisma'],
          correct: 0
        }
      ]
    }
  ]);

  const [selectedExam, setSelectedExam] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [examSubmitted, setExamSubmitted] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Text-to-Speech Helper
  const speakText = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.onend = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#fefce8', color: '#713f12', padding: '36px', fontFamily: "'Inter', sans-serif", boxSizing: 'border-box' }}>
      
      {/* Top Navigation / Back to Dashboard */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px', borderBottom: '2px solid rgba(234, 179, 8, 0.3)', paddingBottom: '24px' }}>
        <button 
          onClick={() => { stopSpeech(); navigate('/dashboard'); }}
          style={{ background: '#fef08a', border: '2px solid #ca8a04', color: '#854d0e', padding: '12px 20px', borderRadius: '12px', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '16px' }}
        >
          <ArrowLeft size={20} /> Back to Student Dashboard
        </button>
        <h1 style={{ fontSize: '24px', color: '#854d0e', margin: 0, fontWeight: '900' }}>Exam & Teacher PDFs Portal</h1>
      </div>

      <div style={{ background: '#ffffff', padding: '36px', borderRadius: '20px', border: '2px solid rgba(234, 179, 8, 0.3)', boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.08)' }}>

        {/* 1. LIST VIEW */}
        {subView === 'list' && (
          <div>
            <div style={{ marginBottom: '32px', borderBottom: '2px solid #fef08a', paddingBottom: '20px' }}>
              <h2 style={{ fontSize: '28px', color: '#854d0e', margin: '0 0 6px 0', fontWeight: '900' }}>Available Materials & Exams</h2>
              <p style={{ fontSize: '16px', color: '#a16207', margin: 0, fontWeight: '600' }}>Select a teacher PDF to read question-by-question or start a timed assessment.</p>
            </div>

            {/* Teacher Uploaded PDFs Section */}
            <div style={{ marginBottom: '40px' }}>
              <h3 style={{ fontSize: '22px', color: '#854d0e', margin: '0 0 16px 0', fontWeight: '800' }}>📄 Teacher Uploaded Question Papers</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {teacherUploadedPdfs.map(pdf => (
                  <div key={pdf.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '22px', background: '#fefce8', borderRadius: '14px', border: '2px solid #fde047' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <FileCheck size={32} color="#ca8a04" />
                      <div>
                        <h4 style={{ fontSize: '20px', fontWeight: '800', margin: '0 0 4px 0', color: '#854d0e' }}>{pdf.title}</h4>
                        <p style={{ fontSize: '15px', color: '#713f12', margin: 0, fontWeight: '600' }}>Subject: {pdf.subject} • {pdf.questions.length} Items • Uploaded by {pdf.uploadedBy}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        setActiveTeacherPdf(pdf);
                        setPdfQuestionIndex(0);
                        setSubView('pdf-viewer');
                        speakText(`Opened teacher document: ${pdf.title}. Item 1 of ${pdf.questions.length}. ${pdf.questions[0]}`);
                      }}
                      style={{ background: '#ca8a04', color: '#fff', border: 'none', padding: '12px 22px', borderRadius: '12px', fontSize: '16px', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}
                    >
                      Open PDF <ArrowRight size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Timed Assessments Section */}
            <div>
              <h3 style={{ fontSize: '22px', color: '#854d0e', margin: '0 0 16px 0', fontWeight: '800' }}>📝 Timed Assessments & Quizzes</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {availableExams.map(ex => (
                  <div key={ex.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '24px', background: '#fefce8', borderRadius: '14px', border: '2px solid #fde047' }}>
                    <div>
                      <h4 style={{ fontSize: '22px', fontWeight: '800', margin: '0 0 6px 0', color: '#854d0e' }}>{ex.title}</h4>
                      <p style={{ fontSize: '16px', color: '#713f12', margin: '0 0 8px 0', fontWeight: '600' }}>Subject: {ex.subject} • Duration: {ex.duration} • {ex.questions.length} Questions</p>
                    </div>
                    <button 
                      onClick={() => {
                        setSelectedExam(ex);
                        setCurrentQuestionIndex(0);
                        setSelectedAnswers({});
                        setExamSubmitted(false);
                        setSubView('exam-active');
                        speakText(`Started exam: ${ex.title}. Question 1. ${ex.questions[0].questionText}`);
                      }}
                      style={{ background: '#ca8a04', color: '#fff', border: 'none', padding: '14px 24px', borderRadius: '12px', fontSize: '16px', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}
                    >
                      Start Exam <ArrowRight size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 2. PDF QUESTION BY QUESTION VIEWER */}
        {subView === 'pdf-viewer' && activeTeacherPdf && (
          <div style={{ background: '#fefce8', padding: '32px', borderRadius: '18px', border: '2px solid #ca8a04' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '2px solid #fde047', paddingBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <span style={{ fontSize: '14px', color: '#a16207', fontWeight: '700' }}>Question Viewer (Item {pdfQuestionIndex + 1} of {activeTeacherPdf.questions.length})</span>
                <h2 style={{ fontSize: '24px', color: '#854d0e', margin: '4px 0 0 0', fontWeight: '900' }}>{activeTeacherPdf.title}</h2>
              </div>
              <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                <button 
                  onClick={() => speakText(activeTeacherPdf.questions[pdfQuestionIndex])}
                  style={{ background: '#ca8a04', color: '#fff', border: 'none', padding: '12px 20px', borderRadius: '10px', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}
                >
                  <Volume2 size={18} /> {isSpeaking ? 'Reading Aloud...' : 'Read Aloud'}
                </button>
                <button 
                  onClick={() => { stopSpeech(); setSubView('list'); setActiveTeacherPdf(null); }}
                  style={{ background: '#fff', border: '2px solid #ca8a04', color: '#854d0e', padding: '12px 20px', borderRadius: '10px', fontWeight: '800', cursor: 'pointer' }}
                >
                  Back to List
                </button>
              </div>
            </div>

            {/* Individual Question Box */}
            <div style={{ background: '#ffffff', padding: '32px', borderRadius: '14px', border: '2px solid #fde047', marginBottom: '24px', minHeight: '140px', display: 'flex', alignItems: 'center' }}>
              <p style={{ fontSize: '22px', lineHeight: '1.6', color: '#713f12', fontWeight: '800', margin: 0 }}>
                {activeTeacherPdf.questions[pdfQuestionIndex]}
              </p>
            </div>

            {/* Navigation Controls */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <button 
                disabled={pdfQuestionIndex === 0}
                onClick={() => {
                  const newIdx = pdfQuestionIndex - 1;
                  setPdfQuestionIndex(newIdx);
                  speakText(activeTeacherPdf.questions[newIdx]);
                }}
                style={{ 
                  background: pdfQuestionIndex === 0 ? '#f1f5f9' : '#fef08a', 
                  color: pdfQuestionIndex === 0 ? '#94a3b8' : '#854d0e', 
                  border: pdfQuestionIndex === 0 ? 'none' : '2px solid #ca8a04', 
                  padding: '14px 24px', 
                  borderRadius: '12px', 
                  fontWeight: '800', 
                  fontSize: '16px',
                  cursor: pdfQuestionIndex === 0 ? 'not-allowed' : 'pointer' 
                }}
              >
                Previous Question
              </button>

              <span style={{ fontSize: '16px', fontWeight: '800', color: '#a16207' }}>
                {pdfQuestionIndex + 1} / {activeTeacherPdf.questions.length}
              </span>

              <button 
                disabled={pdfQuestionIndex === activeTeacherPdf.questions.length - 1}
                onClick={() => {
                  const newIdx = pdfQuestionIndex + 1;
                  setPdfQuestionIndex(newIdx);
                  speakText(activeTeacherPdf.questions[newIdx]);
                }}
                style={{ 
                  background: pdfQuestionIndex === activeTeacherPdf.questions.length - 1 ? '#f1f5f9' : '#ca8a04', 
                  color: pdfQuestionIndex === activeTeacherPdf.questions.length - 1 ? '#94a3b8' : '#fff', 
                  border: 'none', 
                  padding: '14px 28px', 
                  borderRadius: '12px', 
                  fontWeight: '800', 
                  fontSize: '16px',
                  cursor: pdfQuestionIndex === activeTeacherPdf.questions.length - 1 ? 'not-allowed' : 'pointer' 
                }}
              >
                Next Question
              </button>
            </div>
          </div>
        )}

        {/* 3. ACTIVE EXAM VIEW */}
        {subView === 'exam-active' && selectedExam && !examSubmitted && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '2px solid #fef08a', paddingBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '24px', color: '#854d0e', margin: '0 0 4px 0', fontWeight: '900' }}>{selectedExam.title}</h3>
                <p style={{ fontSize: '15px', color: '#a16207', margin: 0, fontWeight: '600' }}>Question {currentQuestionIndex + 1} of {selectedExam.questions.length}</p>
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <button 
                  onClick={() => speakText(`Question ${currentQuestionIndex + 1}. ${selectedExam.questions[currentQuestionIndex].questionText}. Options: ${selectedExam.questions[currentQuestionIndex].options.join(', ')}`)}
                  style={{ background: '#fef08a', border: '2px solid #ca8a04', color: '#854d0e', padding: '10px 18px', borderRadius: '10px', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px' }}
                >
                  <Volume2 size={18} /> Read Aloud
                </button>
                <button 
                  onClick={() => setSubView('list')}
                  style={{ background: '#fff', border: '2px solid #ca8a04', color: '#854d0e', padding: '10px 18px', borderRadius: '10px', fontWeight: '800', cursor: 'pointer' }}
                >
                  Exit Exam
                </button>
              </div>
            </div>

            <div style={{ background: '#fefce8', padding: '28px', borderRadius: '16px', border: '2px solid #fde047', marginBottom: '24px' }}>
              <p style={{ fontSize: '20px', fontWeight: '800', color: '#713f12', margin: '0 0 20px 0' }}>
                {selectedExam.questions[currentQuestionIndex].questionText}
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {selectedExam.questions[currentQuestionIndex].options.map((opt, oIdx) => (
                  <label 
                    key={oIdx} 
                    style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '12px', 
                      padding: '16px', 
                      borderRadius: '12px', 
                      background: selectedAnswers[currentQuestionIndex] === oIdx ? '#fef08a' : '#ffffff', 
                      border: selectedAnswers[currentQuestionIndex] === oIdx ? '2px solid #ca8a04' : '2px solid #fde047', 
                      cursor: 'pointer',
                      fontWeight: '700',
                      fontSize: '16px',
                      color: '#713f12'
                    }}
                  >
                    <input 
                      type="radio" 
                      name={`q-${currentQuestionIndex}`} 
                      checked={selectedAnswers[currentQuestionIndex] === oIdx}
                      onChange={() => setSelectedAnswers({ ...selectedAnswers, [currentQuestionIndex]: oIdx })}
                      style={{ width: '20px', height: '20px', accentColor: '#ca8a04' }}
                    />
                    Option {oIdx + 1}: {opt}
                  </label>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <button 
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)}
                style={{ background: currentQuestionIndex === 0 ? '#f1f5f9' : '#fef08a', color: currentQuestionIndex === 0 ? '#94a3b8' : '#854d0e', border: 'none', padding: '12px 24px', borderRadius: '10px', fontWeight: '800', cursor: currentQuestionIndex === 0 ? 'not-allowed' : 'pointer' }}
              >
                Previous Question
              </button>

              {currentQuestionIndex < selectedExam.questions.length - 1 ? (
                <button 
                  onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}
                  style={{ background: '#ca8a04', color: '#fff', border: 'none', padding: '12px 28px', borderRadius: '10px', fontWeight: '800', cursor: 'pointer' }}
                >
                  Next Question
                </button>
              ) : (
                <button 
                  onClick={() => { setExamSubmitted(true); stopSpeech(); }}
                  style={{ background: '#15803d', color: '#fff', border: 'none', padding: '12px 28px', borderRadius: '10px', fontWeight: '800', cursor: 'pointer' }}
                >
                  Submit Exam
                </button>
              )}
            </div>
          </div>
        )}

        {/* 4. SUBMISSION SUCCESS VIEW */}
        {subView === 'exam-active' && examSubmitted && (
          <div style={{ textAlign: 'center', padding: '40px 20px' }}>
            <CheckCircle size={64} color="#15803d" style={{ marginBottom: '16px' }} />
            <h3 style={{ fontSize: '28px', color: '#854d0e', margin: '0 0 8px 0', fontWeight: '900' }}>Exam Submitted Successfully!</h3>
            <p style={{ fontSize: '18px', color: '#713f12', margin: '0 0 24px 0' }}>Your audio-guided exam has been recorded.</p>
            <button 
              onClick={() => { setSubView('list'); setSelectedExam(null); setExamSubmitted(false); }}
              style={{ background: '#ca8a04', color: '#fff', border: 'none', padding: '14px 28px', borderRadius: '12px', fontSize: '16px', fontWeight: '800', cursor: 'pointer' }}
            >
              Return to Portal List
            </button>
          </div>
        )}

      </div>
    </div>
  );
}