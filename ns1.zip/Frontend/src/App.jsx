import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import VoiceLoginPage from './components/VoiceLoginPage.jsx';
import VoiceRegistrationPage from './components/VoiceRegistration.jsx';
import ForgotPassword from './components/ForgotPassword.jsx';
import HomePage from './components/HomePage.jsx';
import StudentDashboard from './components/StudentDashboard.jsx';
import TeacherDashboard from './components/TeacherDashboard.jsx';
import AdminDashboard from './components/AdminDashboard.jsx';
import ExamPortalPage from './pages/ExamPortalPage.jsx';
import GlobalVoiceAssistant from './components/GlobalVoiceAssistant.jsx';

export default function App() {
  return (
    <Router>
      <GlobalVoiceAssistant />
      <Routes>
        {/* First Landing Page: Login Page */}
        <Route path="/" element={<VoiceLoginPage />} />
        <Route path="/login" element={<VoiceLoginPage />} />
        <Route path="/register" element={<VoiceRegistrationPage />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        
        {/* Home Page */}
        <Route path="/home" element={<HomePage />} />
        
        {/* Dashboards */}
        <Route path="/dashboard" element={<StudentDashboard />} />
        <Route path="/student-dashboard" element={<StudentDashboard />} />
        <Route path="/teacher-dashboard" element={<TeacherDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/exam-portal" element={<ExamPortalPage />} />
      </Routes>
    </Router>
  );
}