// Frontend/src/components/speech.js - ElevenLabs & Browser Speech Assistant for Blind Students
import { speakWithElevenLabs, cancelElevenLabsSpeech } from '../services/elevenlabs';

export async function speakIn(text, lang = 'en-US', options = {}) {
  // Cancel any ongoing speech (both ElevenLabs audio and Web Speech Synthesis)
  cancelSpeech();

  if (!text) {
    if (options.onEnd) options.onEnd();
    return;
  }

  // Preprocess text for clear, accurate pronunciation
  let cleanedText = String(text)
    .replace(/@/g, ' at ')
    .replace(/\bvs\b/gi, ' versus ')
    .replace(/\b(etc\.)\b/gi, ' et cetera ')
    .replace(/\b(e\.g\.)\b/gi, ' for example ')
    .replace(/\b(i\.e\.)\b/gi, ' that is ')
    .replace(/[\/\-_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // Try ElevenLabs AI Voice first
  const elevenLabsSuccess = await speakWithElevenLabs(cleanedText, options);
  if (elevenLabsSuccess) {
    return;
  }

  // Fallback to Browser SpeechSynthesis with slow & clear enunciation
  if (!('speechSynthesis' in window)) {
    if (options.onEnd) options.onEnd();
    return;
  }

  const utterance = new SpeechSynthesisUtterance(cleanedText);
  utterance.lang = lang || 'en-US';
  
  // Set speech rate to 0.80 (Slow and clearly enunciated for blind accessibility)
  utterance.rate = options.rate !== undefined ? options.rate : 0.80;
  utterance.pitch = options.pitch !== undefined ? options.pitch : 1.0;

  utterance.onend = () => {
    if (options.onEnd) options.onEnd();
  };

  utterance.onerror = (event) => {
    if (event.error === 'interrupted') return;
    console.error('SpeechSynthesis error:', event);
    if (options.onEnd) options.onEnd();
  };

  window.speechSynthesis.speak(utterance);
}

export function cancelSpeech() {
  cancelElevenLabsSpeech();
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}