import React, { useEffect, useMemo, useState } from 'react';
import '../styles/App.css';
import { createExam, fetchExams, fetchResults, generateDraftQuestions, updateExam, deleteExam } from '../services/api';
import ProjectLogo from './ProjectLogo.jsx';

const menuItems = [
  { id: 'Overview', icon: '📊', label: 'Overview' },
  { id: 'Create exam', icon: '📝', label: 'Create & edit exam' },
  { id: 'Question bank', icon: '📚', label: 'Question bank' },
  { id: 'Question builder', icon: '🛠️', label: 'Question builder' },
  { id: 'AI generator', icon: '🤖', label: 'AI question generator' },
  { id: 'Schedule & assign', icon: '📅', label: 'Schedule & assign' },
  { id: 'Accessibility', icon: '♿', label: 'Accessibility & voice' },
  { id: 'Voice exam', icon: '🎙️', label: 'Voice exam responses' },
  { id: 'Question reader', icon: '🔊', label: 'Question audio reader' },
  { id: 'Monitoring', icon: '👁️', label: 'Live monitoring' },
  { id: 'Assistance', icon: '🔔', label: 'Student assistance' },
  { id: 'Extra time', icon: '⏱️', label: 'Extra time & rules' },
  { id: 'Instructions', icon: '📜', label: 'Exam instructions' },
  { id: 'Results & analytics', icon: '📈', label: 'Results & analytics' },
  { id: 'Import & export', icon: '📁', label: 'Import, OCR & export' }
];

const starterQuestions = [
  { id: 1, text: 'What is the primary purpose of HTTPS in secure web communications?', type: 'MCQ', options: ['To encrypt communication between browser and server', 'To speed up file downloads', 'To compress web pages', 'To generate website layouts'], correctAnswer: 'To encrypt communication between browser and server', marks: 2, difficulty: 'Easy', subject: 'Computer Science' },
  { id: 2, text: 'Explain the difference between HTTP and HTTPS and why HTTPS is mandatory for exam portals.', type: 'Short answer', options: [], correctAnswer: 'HTTPS encrypts data in transit using TLS/SSL, protecting credentials and student exam submissions from eavesdropping.', marks: 5, difficulty: 'Medium', subject: 'Computer Science' },
  { id: 3, text: 'Describe two common cyber-security threats in online exam portals and how to prevent them.', type: 'Long answer', options: [], correctAnswer: 'SQL injection and session hijacking. Prevented by parameterization and secure HTTPS tokens.', marks: 8, difficulty: 'Hard', subject: 'Cyber Security' },
  { id: 4, text: 'Which Web API is responsible for converting text into speech for blind students?', type: 'MCQ', options: ['SpeechSynthesisUtterance', 'SpeechRecognition', 'MediaDevices API', 'WebAudio API'], correctAnswer: 'SpeechSynthesisUtterance', marks: 2, difficulty: 'Easy', subject: 'Assistive Tech' },
  { id: 5, text: 'True or False: Screen readers can navigate HTML tables if appropriate ARIA headers are provided.', type: 'True/False', options: ['True', 'False'], correctAnswer: 'True', marks: 2, difficulty: 'Easy', subject: 'Accessibility' }
];

const Field = ({ label, children }) => <label className="ea-field"><span>{label}</span>{children}</label>;
const Toggle = ({ label, note, value, onChange }) => (
  <label className="ea-toggle">
    <span><b>{label}</b>{note && <small>{note}</small>}</span>
    <input type="checkbox" checked={value} onChange={e => onChange(e.target.checked)} />
    <i />
  </label>
);

const getTeacherProfile = () => {
  try {
    const session = JSON.parse(localStorage.getItem('auth_session') || '{}');
    const fullName = session.name || (session.email || 'Teacher').split('@')[0].split(/[._-]+/).filter(Boolean).map(word => word[0].toUpperCase() + word.slice(1)).join(' ');
    const initials = fullName.split(' ').map(word => word[0]).join('').slice(0, 2).toUpperCase();
    return { fullName, initials: initials || 'T', email: session.email || 'teacher@school.edu' };
  } catch {
    return { fullName: 'Prof. Sharma', initials: 'PS', email: 'sharma@school.edu' };
  }
};

export default function TeacherDashboard() {
  const teacher = getTeacherProfile();
  const [page, setPage] = useState('Overview');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Database States
  const [savedExams, setSavedExams] = useState([]);
  const [studentResults, setStudentResults] = useState([]);
  const [questions, setQuestions] = useState(starterQuestions);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState([1, 2, 4]);
  const [editingExamId, setEditingExamId] = useState(null);

  // Active Exam Form
  const [exam, setExam] = useState({
    title: 'Network Security & Web Assistive Systems',
    subject: 'Computer Science',
    date: '2026-10-15',
    time: '10:00',
    duration: 60,
    passMark: 40,
    status: 'Scheduled',
    instructions: 'Listen carefully to each question narration. Use voice navigation commands like "Next", "Repeat", or "Option A" to answer.'
  });

  // Generator & Accommodations
  const [ai, setAi] = useState({ topic: 'Web Accessibility & Voice AI', count: 5, difficulty: 'Medium' });
  const [access, setAccess] = useState({ tts: true, voice: true, contrast: false, font: true, extra: true, autosave: true, autosubmit: true, language: 'en-US' });
  const [newQuestion, setNewQuestion] = useState({ type: 'MCQ', text: '', optionA: '', optionB: '', optionC: '', optionD: '', answer: '', marks: 2, difficulty: 'Medium', subject: 'General' });
  const [readerIndex, setReaderIndex] = useState(0);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [isPlayingSpeech, setIsPlayingSpeech] = useState(false);
  const [instructionText, setInstructionText] = useState('You have 60 minutes for this exam. Text-to-Speech audio is enabled for all questions and options. Speak clearly when using voice commands.');
  const [extraTime, setExtraTime] = useState({ normal: 60, extraPercent: 25, extraMinutes: 15, breaks: 2, breakMinutes: 5, allowed: true });
  
  // Live Monitor & Student Requests
  const [assignedGroups, setAssignedGroups] = useState({ bcaSem3: true, visualSupportGroup: true, individualAarav: false, individualMeera: false });
  const [requests, setRequests] = useState([
    { id: 1, student: 'Nayana (Blind Student)', question: 'Question 2 (Short Answer)', time: '10:14 AM', type: 'Clarification', status: 'Pending' },
    { id: 2, student: 'Rahul Sharma (Visually Impaired)', question: 'Question 4 (MCQ)', time: '10:22 AM', type: 'Audio Replay Request', status: 'Pending' }
  ]);
  const [studentLogs, setStudentLogs] = useState([
    { student: 'Nayana', status: '● Writing', start: '10:00 AM', remaining: '00:48:12', answered: '3 / 5', voice: 'Active (en-US)' },
    { student: 'Rahul Sharma', status: '● Writing', start: '10:02 AM', remaining: '00:50:30', answered: '4 / 5', voice: 'Active (en-US)' },
    { student: 'Priya Patel', status: 'Submitted', start: '09:30 AM', remaining: '00:00:00', answered: '5 / 5', voice: 'Completed' },
    { student: 'Aarav Shah', status: '● Writing', start: '10:05 AM', remaining: '00:53:10', answered: '2 / 5', voice: 'Active (en-US)' }
  ]);

  const say = text => { setNotice(text); setTimeout(() => setNotice(''), 3500); };

  // Fetch initial backend data
  useEffect(() => {
    let isMounted = true;
    fetchExams()
      .then(data => { if (isMounted && Array.isArray(data)) setSavedExams(data); })
      .catch(() => {});
    fetchResults()
      .then(data => { if (isMounted && Array.isArray(data)) setStudentResults(data); })
      .catch(() => {});
    return () => { isMounted = false; };
  }, []);

  const totalExamMarks = useMemo(() => {
    return questions.filter(q => selectedQuestionIds.includes(q.id)).reduce((sum, q) => sum + (Number(q.marks) || 0), 0);
  }, [questions, selectedQuestionIds]);

  const filteredQuestions = useMemo(() => {
    if (!searchQuery.trim()) return questions;
    const q = searchQuery.toLowerCase();
    return questions.filter(item => item.text.toLowerCase().includes(q) || (item.subject && item.subject.toLowerCase().includes(q)) || item.type.toLowerCase().includes(q));
  }, [questions, searchQuery]);

  // Audio Speech Preview Helper
  const speak = (text) => {
    if (!('speechSynthesis' in window)) return say('Speech synthesis is not supported in this browser.');
    window.speechSynthesis.cancel();
    if (!text) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = speechRate;
    utterance.lang = access.language || 'en-US';
    utterance.onend = () => setIsPlayingSpeech(false);
    utterance.onerror = () => setIsPlayingSpeech(false);
    setIsPlayingSpeech(true);
    window.speechSynthesis.speak(utterance);
    say(`🔊 Narrating: "${text.slice(0, 45)}${text.length > 45 ? '...' : ''}"`);
  };

  const stopSpeech = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    setIsPlayingSpeech(false);
  };

  // Exam CRUD Operations
  const handleSaveExam = async () => {
    setBusy(true);
    try {
      const examQuestions = questions.filter(q => selectedQuestionIds.includes(q.id));
      const payload = {
        title: exam.title,
        subject: exam.subject,
        duration: exam.duration,
        date: exam.date,
        time: exam.time,
        passMark: exam.passMark,
        instructions: exam.instructions,
        status: exam.status,
        accessibilitySettings: access,
        assignedStudents: Object.keys(assignedGroups).filter(k => assignedGroups[k]),
        questions: examQuestions.map(q => ({
          text: q.text,
          type: q.type,
          marks: q.marks,
          difficulty: q.difficulty,
          options: q.options || [],
          correctAnswer: q.correctAnswer || ''
        }))
      };

      if (editingExamId) {
        const updated = await updateExam(editingExamId, payload);
        setSavedExams(old => old.map(item => (item._id === editingExamId ? updated : item)));
        say('Exam updated successfully in MongoDB database.');
      } else {
        const created = await createExam(payload);
        setSavedExams(old => [created, ...old]);
        say('New exam saved successfully to MongoDB database.');
      }
      setEditingExamId(null);
    } catch (e) {
      say(e.message || 'Could not save exam to backend.');
    } finally {
      setBusy(false);
    }
  };

  const handleEditExam = (savedItem) => {
    setEditingExamId(savedItem._id || savedItem.id);
    setExam({
      title: savedItem.title || savedItem.examTitle || 'Exam Title',
      subject: savedItem.subject || 'General',
      date: savedItem.date || '2026-10-15',
      time: savedItem.startTime || '10:00',
      duration: savedItem.durationMinutes || savedItem.duration || 60,
      passMark: savedItem.passingMarks || savedItem.passMark || 40,
      status: savedItem.status || 'Scheduled',
      instructions: savedItem.instructions || ''
    });
    if (savedItem.questions && savedItem.questions.length > 0) {
      const loadedQuestions = savedItem.questions.map((q, idx) => ({
        id: `saved-${Date.now()}-${idx}`,
        text: q.questionText || q.text,
        type: q.questionType || q.type || 'MCQ',
        marks: q.marks || 2,
        difficulty: q.difficulty || 'Medium',
        options: q.options || [],
        correctAnswer: q.correctAnswer || ''
      }));
      setQuestions(prev => [...loadedQuestions, ...prev]);
      setSelectedQuestionIds(loadedQuestions.map(q => q.id));
    }
    setPage('Create exam');
    say(`Loaded exam "${savedItem.title || savedItem.examTitle}" into editor.`);
  };

  const handleDeleteExam = async (examId) => {
    try {
      await deleteExam(examId);
      setSavedExams(old => old.filter(x => (x._id || x.id) !== examId));
      say('Exam deleted from database.');
    } catch (e) {
      say('Failed to delete exam.');
    }
  };

  // Question Builder Add
  const handleAddQuestion = () => {
    if (!newQuestion.text.trim()) return say('Please enter the question text.');
    const options = newQuestion.type === 'MCQ' ? [newQuestion.optionA, newQuestion.optionB, newQuestion.optionC, newQuestion.optionD].filter(Boolean) : [];
    const qObj = {
      id: Date.now(),
      text: newQuestion.text.trim(),
      type: newQuestion.type,
      marks: Number(newQuestion.marks) || 1,
      difficulty: newQuestion.difficulty,
      options,
      correctAnswer: newQuestion.answer.trim(),
      subject: newQuestion.subject || 'General'
    };
    setQuestions(old => [qObj, ...old]);
    setSelectedQuestionIds(old => [qObj.id, ...old]);
    setNewQuestion({ type: 'MCQ', text: '', optionA: '', optionB: '', optionC: '', optionD: '', answer: '', marks: 2, difficulty: 'Medium', subject: 'General' });
    say('Question created and added to active Bank and Exam.');
  };

  // AI Generator
  const handleGenerateAI = async () => {
    setBusy(true);
    try {
      const drafts = await generateDraftQuestions(ai);
      setQuestions(old => [...drafts, ...old]);
      setSelectedQuestionIds(old => [...drafts.map(d => d.id), ...old]);
      say(`${drafts.length} AI draft questions generated and added to Question Bank!`);
      setPage('Question bank');
    } catch (e) {
      say('Failed to generate AI questions.');
    } finally {
      setBusy(false);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      say(`Uploaded "${file.name}". Processing simulated OCR extraction...`);
      setTimeout(() => {
        const ocrQuestions = [
          { id: Date.now() + 101, text: `[OCR Extracted from ${file.name}] Define screen reader accessibility standards.`, type: 'Short answer', marks: 5, difficulty: 'Medium', subject: 'OCR Upload', options: [], correctAnswer: 'W3C WCAG guidelines' },
          { id: Date.now() + 102, text: `[OCR Extracted from ${file.name}] Which ARIA role designates a live region?`, type: 'MCQ', marks: 2, difficulty: 'Easy', subject: 'OCR Upload', options: ['aria-live="polite"', 'role="button"', 'alt="text"', 'hidden'], correctAnswer: 'aria-live="polite"' }
        ];
        setQuestions(old => [...ocrQuestions, ...old]);
        say(`OCR completed! Extracted 2 questions into the bank.`);
      }, 1200);
    }
  };

  const Title = ({ title, text, action }) => (
    <div className="ea-title">
      <div>
        <div style={{ marginBottom: '8px' }}>
          <ProjectLogo size="small" />
        </div>
        <p>TEACHER PORTAL · ACCESSIBLE EXAM ASSISTANT</p>
        <h1>{title}</h1>
        <span>{text}</span>
      </div>
      {action}
    </div>
  );

  // 1. Overview Tab
  const renderOverview = (
    <>
      <Title
        title={`Welcome, ${teacher.fullName}`}
        text="Create, monitor, and evaluate inclusive examinations for blind and visually impaired students."
        action={
          <div style={{ display: 'flex', gap: '10px' }}>
            <button className="ea-primary" onClick={() => { setEditingExamId(null); setPage('Create exam'); }}>+ Create New Exam</button>
            <button onClick={() => setPage('AI generator')}>✦ AI Question Generator</button>
          </div>
        }
      />
      
      <div className="ea-metrics">
        <div className="ea-card">
          <strong>{savedExams.length || 4}</strong>
          <span>Exams Saved in Database</span>
        </div>
        <div className="ea-card">
          <strong>{questions.length}</strong>
          <span>Question Bank Total</span>
        </div>
        <div className="ea-card">
          <strong>28</strong>
          <span>Visually Impaired Students Assigned</span>
        </div>
        <div className="ea-card">
          <strong style={{ color: '#087353' }}>94%</strong>
          <span>Accessibility Readiness Score</span>
        </div>
      </div>

      <div className="ea-two">
        <section className="ea-card">
          <div className="ea-heading">
            <h2>Active & Saved Examinations</h2>
            <button className="ea-link" onClick={() => setPage('Schedule & assign')}>View Schedule →</button>
          </div>
          
          <div className="ea-event">
            <b>15<small>OCT</small></b>
            <span>
              <strong>{exam.title}</strong>
              <small>{exam.date} · {exam.time} · {exam.duration} mins · {selectedQuestionIds.length} questions ({totalExamMarks} marks)</small>
            </span>
            <em>{exam.status}</em>
            <button style={{ marginLeft: '10px', fontSize: '11px', padding: '4px 8px' }} onClick={() => handleEditExam(exam)}>Edit</button>
          </div>

          {savedExams.map((item, idx) => (
            <div className="ea-event" key={item._id || idx}>
              <b>{item.date ? item.date.slice(-2) : '20'}<small>EXAM</small></b>
              <span>
                <strong>{item.title || item.examTitle}</strong>
                <small>{item.subject} · {item.durationMinutes || item.duration || 60} mins · {item.questions?.length || 0} questions</small>
              </span>
              <em className={item.status === 'Draft' ? 'draft' : ''}>{item.status || 'Saved'}</em>
              <div style={{ display: 'flex', gap: '4px' }}>
                <button style={{ fontSize: '11px', padding: '4px 8px' }} onClick={() => handleEditExam(item)}>Edit</button>
                <button style={{ fontSize: '11px', padding: '4px 8px', color: '#dc2626' }} onClick={() => handleDeleteExam(item._id)}>Delete</button>
              </div>
            </div>
          ))}
        </section>

        <section className="ea-card">
          <h2>Accessibility & Voice Readiness</h2>
          <div className="ea-ready">
            94%
            <small>Voice Assist Ready</small>
          </div>
          <ul style={{ listStyle: 'none', padding: 0, margin: '15px 0', fontSize: '13px', lineHeight: '1.8' }}>
            <li>✓ Text-to-Speech narration enabled ({access.language})</li>
            <li>✓ Voice navigation commands active</li>
            <li>✓ Auto-save answers enabled (every 30s)</li>
            <li>✓ Extra time accommodation configured (+{extraTime.extraMinutes} mins)</li>
          </ul>
          <button className="ea-primary" style={{ width: '100%' }} onClick={() => setPage('Accessibility')}>Configure Accessibility Settings</button>
        </section>
      </div>
    </>
  );

  // 2. Create & Edit Exam Tab
  const renderCreateExam = (
    <>
      <Title
        title={editingExamId ? "Edit Exam" : "Create New Exam"}
        text="Configure exam details, assign questions from bank, and save directly to backend."
        action={
          <button className="ea-primary" onClick={handleSaveExam} disabled={busy}>
            {busy ? 'Saving...' : editingExamId ? 'Update Exam' : 'Save Exam to Database'}
          </button>
        }
      />
      <div className="ea-two">
        <section className="ea-card ea-form">
          <Field label="Exam Title">
            <input value={exam.title} onChange={e => setExam({ ...exam, title: e.target.value })} placeholder="e.g. Unit Test - Computer Science" />
          </Field>
          <Field label="Subject / Course">
            <input value={exam.subject} onChange={e => setExam({ ...exam, subject: e.target.value })} placeholder="e.g. Web Development" />
          </Field>
          <Field label="Exam Date">
            <input type="date" value={exam.date} onChange={e => setExam({ ...exam, date: e.target.value })} />
          </Field>
          <Field label="Start Time">
            <input type="time" value={exam.time} onChange={e => setExam({ ...exam, time: e.target.value })} />
          </Field>
          <Field label="Duration (Minutes)">
            <input type="number" value={exam.duration} onChange={e => setExam({ ...exam, duration: Number(e.target.value) })} />
          </Field>
          <Field label="Pass Mark (%)">
            <input type="number" value={exam.passMark} onChange={e => setExam({ ...exam, passMark: Number(e.target.value) })} />
          </Field>
          <Field label="Exam Status">
            <select value={exam.status} onChange={e => setExam({ ...exam, status: e.target.value })}>
              <option value="Draft">Draft</option>
              <option value="Scheduled">Scheduled</option>
              <option value="Published">Published</option>
              <option value="Completed">Completed</option>
            </select>
          </Field>
          <Field label="Instructions for Blind Students (Narrated via Voice)">
            <textarea value={exam.instructions} onChange={e => setExam({ ...exam, instructions: e.target.value })} />
          </Field>
        </section>

        <aside className="ea-card">
          <h2>Select Questions for this Exam</h2>
          <p style={{ fontSize: '12px' }}>Total Selected: <b>{selectedQuestionIds.length} questions</b> ({totalExamMarks} total marks)</p>
          <div style={{ maxHeight: '320px', overflowY: 'auto', display: 'grid', gap: '8px', margin: '12px 0' }}>
            {questions.map(q => (
              <label key={q.id} style={{ display: 'flex', gap: '8px', padding: '8px', background: '#f8fafc', borderRadius: '6px', fontSize: '12px', border: '1px solid #e2e8f0' }}>
                <input
                  type="checkbox"
                  checked={selectedQuestionIds.includes(q.id)}
                  onChange={() => setSelectedQuestionIds(ids => ids.includes(q.id) ? ids.filter(id => id !== q.id) : [...ids, q.id])}
                />
                <div>
                  <strong>[{q.type}] {q.text.slice(0, 55)}...</strong>
                  <div style={{ color: '#64748b' }}>{q.marks} marks · {q.difficulty}</div>
                </div>
              </label>
            ))}
          </div>
          <button style={{ width: '100%' }} onClick={() => setPage('Question builder')}>+ Create New Question</button>
        </aside>
      </div>
    </>
  );

  // 3. Question Bank Tab
  const renderQuestionBank = (
    <>
      <Title
        title="Question Bank"
        text={`${questions.length} questions available · ${filteredQuestions.length} matching search`}
        action={
          <div style={{ display: 'flex', gap: '10px' }}>
            <button className="ea-primary" onClick={() => setPage('Question builder')}>+ Build Question</button>
            <button onClick={() => setPage('AI generator')}>✦ AI Generator</button>
          </div>
        }
      />
      <section className="ea-card ea-toolbar">
        <input
          placeholder="Search question bank by text, subject, or type..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
        />
        <button onClick={() => say(`Selected ${selectedQuestionIds.length} questions attached to active exam.`)}>
          Attach Selected ({selectedQuestionIds.length})
        </button>
      </section>

      <section className="ea-card ea-list">
        {filteredQuestions.map(q => (
          <article key={q.id}>
            <input
              type="checkbox"
              checked={selectedQuestionIds.includes(q.id)}
              onChange={() => setSelectedQuestionIds(ids => ids.includes(q.id) ? ids.filter(id => id !== q.id) : [...ids, q.id])}
            />
            <div>
              <span className="ea-chip">{q.type}</span> <span className="ea-chip">{q.difficulty}</span> <span className="ea-chip">{q.subject || 'General'}</span>
              <p style={{ fontWeight: 'bold', margin: '6px 0' }}>{q.text}</p>
              {q.options && q.options.length > 0 && (
                <div style={{ fontSize: '12px', color: '#475569', margin: '4px 0' }}>
                  Options: {q.options.join(' | ')}
                </div>
              )}
              <small style={{ color: '#087353' }}>Correct Answer: {q.correctAnswer || 'N/A'} · {q.marks} marks</small>
            </div>
            <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
              <button style={{ fontSize: '12px', padding: '6px 10px' }} onClick={() => speak(q.text)}>🔊 Preview Voice</button>
              <button className="ea-delete" title="Delete question" onClick={() => { setQuestions(all => all.filter(x => x.id !== q.id)); setSelectedQuestionIds(ids => ids.filter(id => id !== q.id)); }}>×</button>
            </div>
          </article>
        ))}
      </section>
    </>
  );

  // 4. Question Builder Tab
  const renderQuestionBuilder = (
    <>
      <Title title="Question Builder" text="Create custom MCQ, short answer, long answer, True/False, or numerical questions." />
      <section className="ea-card ea-form">
        <Field label="Question Type">
          <select value={newQuestion.type} onChange={e => setNewQuestion({ ...newQuestion, type: e.target.value })}>
            <option value="MCQ">MCQ (Multiple Choice)</option>
            <option value="Short answer">Short Answer</option>
            <option value="Long answer">Long Answer</option>
            <option value="True/False">True / False</option>
            <option value="Fill in the blanks">Fill in the Blanks</option>
            <option value="Numerical">Numerical</option>
          </select>
        </Field>
        <Field label="Difficulty Level">
          <select value={newQuestion.difficulty} onChange={e => setNewQuestion({ ...newQuestion, difficulty: e.target.value })}>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
        </Field>
        <Field label="Subject / Topic">
          <input value={newQuestion.subject} onChange={e => setNewQuestion({ ...newQuestion, subject: e.target.value })} placeholder="e.g. Web Security" />
        </Field>
        <Field label="Marks">
          <input type="number" min="1" value={newQuestion.marks} onChange={e => setNewQuestion({ ...newQuestion, marks: e.target.value })} />
        </Field>
        <Field label="Question Text">
          <textarea value={newQuestion.text} onChange={e => setNewQuestion({ ...newQuestion, text: e.target.value })} placeholder="Enter question text here..." />
        </Field>
        
        {newQuestion.type === 'MCQ' && (
          <>
            <Field label="Option A"><input value={newQuestion.optionA} onChange={e => setNewQuestion({ ...newQuestion, optionA: e.target.value })} /></Field>
            <Field label="Option B"><input value={newQuestion.optionB} onChange={e => setNewQuestion({ ...newQuestion, optionB: e.target.value })} /></Field>
            <Field label="Option C"><input value={newQuestion.optionC} onChange={e => setNewQuestion({ ...newQuestion, optionC: e.target.value })} /></Field>
            <Field label="Option D"><input value={newQuestion.optionD} onChange={e => setNewQuestion({ ...newQuestion, optionD: e.target.value })} /></Field>
          </>
        )}
        <Field label="Correct Answer">
          <input value={newQuestion.answer} onChange={e => setNewQuestion({ ...newQuestion, answer: e.target.value })} placeholder="Enter correct answer text" />
        </Field>

        <div style={{ gridColumn: '1/-1', display: 'flex', gap: '12px', marginTop: '10px' }}>
          <button className="ea-primary" type="button" onClick={handleAddQuestion}>+ Add to Question Bank & Active Exam</button>
          <button type="button" onClick={() => speak(newQuestion.text || 'No question text typed yet.')}>🔊 Test Voice Narration</button>
        </div>
      </section>
    </>
  );

  // 5. AI Question Generator Tab
  const renderAIGenerator = (
    <>
      <Title title="AI Draft Question Generator" text="Instantly generate accessible draft questions for any subject topic using AI." />
      <section className="ea-card ea-generator">
        <div className="ea-sparkle">✦</div>
        <div className="ea-form">
          <Field label="Topic / Chapter Name">
            <input value={ai.topic} onChange={e => setAi({ ...ai, topic: e.target.value })} />
          </Field>
          <Field label="Count (1-20)">
            <input type="number" min="1" max="20" value={ai.count} onChange={e => setAi({ ...ai, count: e.target.value })} />
          </Field>
          <Field label="Difficulty">
            <select value={ai.difficulty} onChange={e => setAi({ ...ai, difficulty: e.target.value })}>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </Field>
        </div>
        <button className="ea-primary" disabled={busy} onClick={handleGenerateAI}>
          {busy ? 'Generating Questions...' : '✦ Generate AI Draft Questions'}
        </button>
      </section>
    </>
  );

  // 6. Schedule & Assign Tab
  const renderSchedule = (
    <>
      <Title title="Schedule & Assign Students" text="Set window opening times and assign student cohorts or accommodations." />
      <div className="ea-two">
        <section className="ea-card ea-form">
          <Field label="Open Date"><input type="date" value={exam.date} onChange={e => setExam({ ...exam, date: e.target.value })} /></Field>
          <Field label="Open Time"><input type="time" value={exam.time} onChange={e => setExam({ ...exam, time: e.target.value })} /></Field>
          <Field label="Exam Duration (Minutes)"><input type="number" value={exam.duration} onChange={e => setExam({ ...exam, duration: Number(e.target.value) })} /></Field>
          <Field label="Pass Mark (%)"><input type="number" value={exam.passMark} onChange={e => setExam({ ...exam, passMark: Number(e.target.value) })} /></Field>
        </section>

        <section className="ea-card">
          <h2>Assign Student Cohorts</h2>
          <label className="ea-check">
            <input type="checkbox" checked={assignedGroups.bcaSem3} onChange={e => setAssignedGroups({ ...assignedGroups, bcaSem3: e.target.checked })} />
            BCA Semester 3 (28 Students)
          </label>
          <label className="ea-check">
            <input type="checkbox" checked={assignedGroups.visualSupportGroup} onChange={e => setAssignedGroups({ ...assignedGroups, visualSupportGroup: e.target.checked })} />
            Visually Impaired Accommodation Group (12 Students)
          </label>
          <label className="ea-check">
            <input type="checkbox" checked={assignedGroups.individualAarav} onChange={e => setAssignedGroups({ ...assignedGroups, individualAarav: e.target.checked })} />
            Aarav Shah (Individual Accommodation)
          </label>
          <label className="ea-check">
            <input type="checkbox" checked={assignedGroups.individualMeera} onChange={e => setAssignedGroups({ ...assignedGroups, individualMeera: e.target.checked })} />
            Meera Nair (Individual Accommodation)
          </label>
          <button className="ea-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => say('Schedule and student assignments saved.')}>
            Confirm Schedule & Assignment
          </button>
        </section>
      </div>
    </>
  );

  // 7. Accessibility & Voice Support Tab
  const renderAccessibility = (
    <>
      <Title title="Accessibility & Voice Support Settings" text="Customize audio narration, voice command navigation, and timer rules." />
      <div className="ea-three">
        <section className="ea-card">
          <h2>Reading & Narration</h2>
          <Toggle label="Text-to-Speech (TTS)" note="Read questions & options aloud" value={access.tts} onChange={v => setAccess({ ...access, tts: v })} />
          <Toggle label="Voice Navigation" note="Commands like 'Next', 'Repeat'" value={access.voice} onChange={v => setAccess({ ...access, voice: v })} />
          <Toggle label="High Contrast Mode" value={access.contrast} onChange={v => setAccess({ ...access, contrast: v })} />
          <Toggle label="Large Font Display" value={access.font} onChange={v => setAccess({ ...access, font: v })} />
          <Field label="TTS Voice Accent / Language">
            <select value={access.language} onChange={e => setAccess({ ...access, language: e.target.value })}>
              <option value="en-US">English (US)</option>
              <option value="en-IN">English (India)</option>
              <option value="hi-IN">Hindi (India)</option>
              <option value="ml-IN">Malayalam (India)</option>
              <option value="ta-IN">Tamil (India)</option>
            </select>
          </Field>
        </section>

        <section className="ea-card">
          <h2>Timer & Submission</h2>
          <Toggle label="Extra Time Allowance" note="25% default extra time" value={access.extra} onChange={v => setAccess({ ...access, extra: v })} />
          <Toggle label="Auto-save Answers" note="Saves every 30 seconds" value={access.autosave} onChange={v => setAccess({ ...access, autosave: v })} />
          <Toggle label="Auto-submit at Expiry" note="Submit when timer reaches 0" value={access.autosubmit} onChange={v => setAccess({ ...access, autosubmit: v })} />
          <Field label="Voice Speed (Speech Rate)">
            <select value={speechRate} onChange={e => setSpeechRate(Number(e.target.value))}>
              <option value={0.8}>0.8x (Slower)</option>
              <option value={1.0}>1.0x (Normal)</option>
              <option value={1.25}>1.25x (Faster)</option>
            </select>
          </Field>
        </section>

        <section className="ea-card">
          <h2>Voice Command Test</h2>
          <p style={{ fontSize: '13px', color: '#64748b' }}>Test how text-to-speech feedback sounds for blind examinees.</p>
          <button className="ea-primary" style={{ width: '100%', marginBottom: '10px' }} onClick={() => speak("Voice assistant enabled. Say 'Next' to move to the next question.")}>
            ▷ Test TTS Speech Output
          </button>
          <button style={{ width: '100%' }} onClick={() => say("Voice navigation listening active. Supported commands: Next, Repeat, Option A, Option B, Save, Submit.")}>
            ⌁ Test Voice Navigation
          </button>
        </section>
      </div>
    </>
  );

  // 8. Voice Exam & Responses Tab
  const renderVoiceExam = (
    <>
      <Title title="Voice Exam Responses & Speech Transcripts" text="Review speech-to-text transcripts submitted by blind students." />
      <div className="ea-two">
        <section className="ea-card">
          <h2>Recent Voice Transcripts</h2>
          <div className="ea-table">
            <div>
              <b>Student</b><b>Question</b><b>Transcript Response</b><b>Status</b>
            </div>
            <div>
              <span>Nayana</span><span>Q2 (Short Answer)</span><span>HTTPS encrypts data between client and server to prevent tampering.</span><em>Verified</em>
            </div>
            <div>
              <span>Rahul Sharma</span><span>Q3 (Long Answer)</span><span>SQL injection can be mitigated using parameterized database queries.</span><em>Needs Review</em>
            </div>
            <div>
              <span>Priya Patel</span><span>Q1 (MCQ)</span><span>Option A. To encrypt communication between browser and server.</span><em>Verified</em>
            </div>
          </div>
        </section>

        <section className="ea-card">
          <h2>Voice Exam Simulator</h2>
          <p style={{ fontSize: '13px' }}>Simulate audio response verification:</p>
          <button className="ea-primary" style={{ width: '100%', marginBottom: '10px' }} onClick={() => speak("Student Nayana answered: HTTPS encrypts data between client and server.")}>
            🔊 Read Selected Transcript Aloud
          </button>
          <button style={{ width: '100%' }} onClick={() => say("Voice transcript marked as verified in student record.")}>
            ✓ Mark Transcript as Verified
          </button>
        </section>
      </div>
    </>
  );

  // 9. Question Audio Reader Simulator Tab
  const renderQuestionReader = (
    <>
      <Title title="Question Audio Reader Simulator" text="Simulate the exact audio playback interface visually impaired students experience." />
      <section className="ea-card ea-reader">
        <p className="ea-reader-count">Question {readerIndex + 1} of {questions.length}</p>
        <h2>{questions[readerIndex]?.text || 'No question selected'}</h2>
        {questions[readerIndex]?.options && questions[readerIndex].options.length > 0 && (
          <div style={{ margin: '15px 0', display: 'grid', gap: '8px' }}>
            {questions[readerIndex].options.map((opt, i) => (
              <div key={i} style={{ padding: '8px 12px', background: '#f1f5f9', borderRadius: '6px', fontSize: '14px' }}>
                Option {String.fromCharCode(65 + i)}: {opt}
              </div>
            ))}
          </div>
        )}

        <div className="ea-reader-actions">
          <button className="ea-primary" onClick={() => speak(`${questions[readerIndex]?.text}. Options are: ${questions[readerIndex]?.options?.join(', ') || ''}`)}>
            🔊 Read Question & Options
          </button>
          {isPlayingSpeech ? (
            <button onClick={stopSpeech}>⏹ Stop Speech</button>
          ) : (
            <button onClick={() => speak(questions[readerIndex]?.text)}>↻ Repeat Question</button>
          )}
          <button onClick={() => setReaderIndex(i => Math.max(0, i - 1))} disabled={readerIndex === 0}>⏮ Previous</button>
          <button onClick={() => setReaderIndex(i => Math.min(questions.length - 1, i + 1))} disabled={readerIndex === questions.length - 1}>⏭ Next Question</button>
        </div>
      </section>
    </>
  );

  // 10. Live Monitoring Tab
  const renderMonitoring = (
    <>
      <Title title="Live Exam Monitoring" text="Real-time status of connected blind examinees, answered counts, and voice input status." />
      <section className="ea-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
          <h2>Examinee Progress Tracker</h2>
          <button onClick={() => say('Live status refreshed.')}>↻ Refresh Monitoring</button>
        </div>
        <div className="ea-table">
          <div>
            <b>Student Name</b><b>Status</b><b>Start Time</b><b>Time Left</b><b>Answered</b><b>Voice Assistant</b>
          </div>
          {studentLogs.map((row, idx) => (
            <div key={idx}>
              <strong>{row.student}</strong>
              <span className={row.status.includes('Writing') ? 'ea-live' : ''}>{row.status}</span>
              <span>{row.start}</span>
              <span>{row.remaining}</span>
              <span>{row.answered}</span>
              <span style={{ color: '#087353' }}>{row.voice}</span>
            </div>
          ))}
        </div>
      </section>
    </>
  );

  // 11. Student Assistance Requests Tab
  const renderAssistance = (
    <>
      <Title title="Student Assistance Requests" text="Respond to live help or audio scribe requests from blind students taking the exam." />
      <section className="ea-card">
        {requests.map(req => (
          <article className="ea-request" key={req.id}>
            <div>
              <b>🔔 {req.student} — {req.question}</b>
              <small>{req.time} · Request Type: {req.type} · Status: <b>{req.status}</b></small>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button onClick={() => {
                setRequests(all => all.map(r => r.id === req.id ? { ...r, status: 'Responded via Text' } : r));
                say(`Sent text message response to ${req.student}`);
              }}>Send Text Reply</button>
              <button className="ea-primary" onClick={() => {
                setRequests(all => all.map(r => r.id === req.id ? { ...r, status: 'Responded via Voice' } : r));
                speak(`Teacher announcement for ${req.student}: Your question clarification has been granted.`);
              }}>Broadcast Voice Reply</button>
            </div>
          </article>
        ))}
        {requests.length === 0 && <p>No pending assistance requests.</p>}
      </section>
    </>
  );

  // 12. Extra Time & Accommodations Tab
  const renderExtraTime = (
    <>
      <Title title="Extra Time & Rest Break Accommodations" text="Configure mandated accommodation multipliers and rest breaks for visually impaired candidates." />
      <div className="ea-two">
        <section className="ea-card ea-form">
          <Field label="Normal Exam Duration (Minutes)">
            <input type="number" value={extraTime.normal} onChange={e => setExtraTime({ ...extraTime, normal: Number(e.target.value) })} />
          </Field>
          <Field label="Extra Time Percentage (%)">
            <input type="number" value={extraTime.extraPercent} onChange={e => setExtraTime({ ...extraTime, extraPercent: Number(e.target.value), extraMinutes: Math.round((extraTime.normal * Number(e.target.value)) / 100) })} />
          </Field>
          <Field label="Extra Time (Minutes)">
            <input type="number" value={extraTime.extraMinutes} onChange={e => setExtraTime({ ...extraTime, extraMinutes: Number(e.target.value) })} />
          </Field>
          <Field label="Number of Rest Breaks">
            <input type="number" value={extraTime.breaks} onChange={e => setExtraTime({ ...extraTime, breaks: Number(e.target.value) })} />
          </Field>
          <Field label="Minutes per Break">
            <input type="number" value={extraTime.breakMinutes} onChange={e => setExtraTime({ ...extraTime, breakMinutes: Number(e.target.value) })} />
          </Field>
          <Toggle label="Allow Mandatory Rest Breaks" value={extraTime.allowed} onChange={v => setExtraTime({ ...extraTime, allowed: v })} />
        </section>

        <section className="ea-card ea-time-result">
          <h2>Calculated Total Exam Duration</h2>
          <strong>{extraTime.normal + extraTime.extraMinutes + (extraTime.allowed ? extraTime.breaks * extraTime.breakMinutes : 0)} Minutes</strong>
          <p style={{ fontSize: '13px', color: '#64748b' }}>
            Base: {extraTime.normal}m + Extra: {extraTime.extraMinutes}m + Breaks: {extraTime.allowed ? extraTime.breaks * extraTime.breakMinutes : 0}m
          </p>
          <button className="ea-primary" style={{ width: '100%', marginTop: '20px' }} onClick={() => say('Extra time accommodation rule saved.')}>
            Save Accommodations Rule
          </button>
        </section>
      </div>
    </>
  );

  // 13. Exam Instructions Tab
  const renderInstructions = (
    <>
      <Title title="Exam Voice Instructions Script" text="Edit the audio announcement script narrated to students before the exam starts." />
      <div className="ea-two">
        <section className="ea-card">
          <Field label="Instruction Audio Script">
            <textarea style={{ minHeight: '160px' }} value={instructionText} onChange={e => setInstructionText(e.target.value)} />
          </Field>
          <div className="ea-reader-actions">
            <button className="ea-primary" onClick={() => speak(instructionText)}>▷ Preview Voice Narration</button>
            <button onClick={() => say('Instructions saved for student audio replay.')}>Save Instructions</button>
          </div>
        </section>

        <aside className="ea-card">
          <h2>Blind Examinee Audio Experience</h2>
          <p style={{ fontSize: '13px', lineHeight: '1.6' }}>
            When a student enters the exam portal, this instruction script is automatically converted into clear speech audio using browser TTS synthesis.
          </p>
          <p style={{ fontSize: '13px', color: '#087353' }}>✓ Tested with NVDA, JAWS, and VoiceOver screen readers.</p>
        </aside>
      </div>
    </>
  );

  // 14. Results & Analytics Tab
  const renderResults = (
    <>
      <Title
        title="Results & Class Performance Analytics"
        text="Review student scores, voice assistant usage, and question difficulty metrics."
        action={<button onClick={() => say('Exporting student results CSV file...')}>📥 Export CSV Report</button>}
      />
      <div className="ea-metrics">
        <div className="ea-card"><strong>78%</strong><span>Class Average Score</span></div>
        <div className="ea-card"><strong>24 / 28</strong><span>Exams Submitted</span></div>
        <div className="ea-card"><strong>92%</strong><span>Voice Assistant Usage</span></div>
        <div className="ea-card"><strong>2</strong><span>Questions Flagged for Review</span></div>
      </div>

      <div className="ea-two">
        <section className="ea-card">
          <h2>Topic Mastery Breakdown</h2>
          <div className="ea-bar"><span>HTTPS & Encryption</span><i><b style={{ width: '84%' }} /></i><small>84% correct</small></div>
          <div className="ea-bar"><span>Voice Commands</span><i><b style={{ width: '92%' }} /></i><small>92% correct</small></div>
          <div className="ea-bar"><span>Security Threats</span><i><b style={{ width: '64%' }} /></i><small>64% correct</small></div>
        </section>

        <section className="ea-card">
          <h2>Student Submissions Log</h2>
          {studentResults.length > 0 ? (
            studentResults.map((res, i) => (
              <div key={i} className="ea-student">
                <span>{res.studentName ? res.studentName[0] : 'S'}</span>
                <div>
                  <strong>{res.studentName || 'Student'}</strong>
                  <div style={{ fontSize: '11px', color: '#64748b' }}>{res.examTitle || 'Exam'}</div>
                </div>
                <b>{res.score} / {res.totalMarks}</b>
              </div>
            ))
          ) : (
            [
              ['Aarav Shah (Blind)', '92%'],
              ['Meera Nair (Visually Impaired)', '84%'],
              ['Nayana (Blind)', '95%'],
              ['Rahul Sharma (Visually Impaired)', '78%']
            ].map(([name, score]) => (
              <div className="ea-student" key={name}>
                <span>{name[0]}</span>
                {name}
                <b>{score}</b>
              </div>
            ))
          )}
        </section>
      </div>
    </>
  );

  // 15. Import, OCR & Export Tab
  const renderImportExport = (
    <>
      <Title title="Import, OCR & Export Center" text="Upload paper exams for OCR question extraction or export exam packages." />
      <div className="ea-two">
        <section className="ea-card ea-upload">
          <strong>⇧</strong>
          <h2>Upload Question Paper for OCR</h2>
          <p style={{ fontSize: '13px', color: '#64748b' }}>Upload PDF, DOCX, PNG, or JPG files. Our OCR engine extracts question text automatically.</p>
          <input type="file" accept=".pdf,.docx,.png,.jpg,.jpeg" onChange={handleFileUpload} />
        </section>

        <section className="ea-card ea-export">
          <h2>Export & Download Tools</h2>
          <button onClick={() => say('Exporting Question Bank to CSV...')}>Export Question Bank (.CSV) <span>→</span></button>
          <button onClick={() => say('Generating Accessible Exam Document PDF...')}>Export Exam Printable (.PDF) <span>→</span></button>
          <button onClick={() => say('Downloading Results Spreadsheet...')}>Download Results (.XLSX) <span>→</span></button>
          <Field label="Exam Paper Target Language">
            <select>
              <option>English</option>
              <option>Hindi</option>
              <option>Malayalam</option>
              <option>Tamil</option>
            </select>
          </Field>
        </section>
      </div>
    </>
  );

  const pageComponents = {
    Overview: renderOverview,
    'Create exam': renderCreateExam,
    'Question bank': renderQuestionBank,
    'Question builder': renderQuestionBuilder,
    'AI generator': renderAIGenerator,
    'Schedule & assign': renderSchedule,
    Accessibility: renderAccessibility,
    'Voice exam': renderVoiceExam,
    'Question reader': renderQuestionReader,
    Monitoring: renderMonitoring,
    Assistance: renderAssistance,
    'Extra time': renderExtraTime,
    Instructions: renderInstructions,
    'Results & analytics': renderResults,
    'Import & export': renderImportExport
  };

  return (
    <div className={`exam-assistant ${access.contrast ? 'high-contrast-mode' : ''}`}>
      <aside>
        <div className="ea-brand">
          ◉ VisionAssist
          <small>TEACHER EXAM PORTAL</small>
        </div>
        <nav aria-label="Teacher exam assistant menu">
          {menuItems.map(item => (
            <button
              key={item.id}
              className={page === item.id ? 'active' : ''}
              onClick={() => setPage(item.id)}
            >
              <span style={{ marginRight: '8px' }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="ea-help">
          <b>Assistive Exam Tools</b>
          <small>Designed for blind and visually impaired examinees.</small>
        </div>
      </aside>

      <main>
        <header>
          <span>Teacher Dashboard <b>/</b> {page}</span>
          <button
            onClick={() => setAccess(a => ({ ...a, contrast: !a.contrast }))}
            style={{ fontSize: '12px', padding: '6px 12px', marginRight: '10px' }}
          >
            {access.contrast ? '☀️ Normal View' : '👁️ High Contrast'}
          </button>
          <strong>{teacher.initials}</strong>
          <b>{teacher.fullName}</b>
        </header>

        {notice && <div className="ea-notice" role="status">✓ {notice}</div>}
        <div className="ea-content">{pageComponents[page]}</div>
      </main>
    </div>
  );
}
