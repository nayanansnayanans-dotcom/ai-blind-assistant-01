import React, { useState } from "react";
import { speakText } from "../utils/languages";

const AdminRegistration = ({ goToLogin }) => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [adminSecretKey, setAdminSecretKey] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleSpeak = (text) => {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    speakText(text, "en-US");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      const response = await fetch("http://localhost:5000/api/auth/register-admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          email,
          phone,
          password,
          adminSecretKey,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess("Admin registered successfully!");
        handleSpeak("Admin account registered successfully!");
        setTimeout(() => {
          if (goToLogin) goToLogin();
        }, 1500);
      } else {
        setError(data.message);
        handleSpeak(`Error: ${data.message}`);
      }
    } catch (err) {
      setError("Failed to connect to server");
      handleSpeak("Error connecting to server");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title} onMouseEnter={() => handleSpeak("Admin Registration Screen")}>
          👑 Admin Registration
        </h2>

        {error && <div style={styles.errorBox}>{error}</div>}
        {success && <div style={styles.successBox}>{success}</div>}

        <form onSubmit={handleSubmit} style={styles.form}>
          <input
            type="text"
            placeholder="Admin Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onMouseEnter={() => handleSpeak("Admin username field")}
            required
            style={styles.input}
          />
          <input
            type="email"
            placeholder="Admin Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onMouseEnter={() => handleSpeak("Admin email field")}
            required
            style={styles.input}
          />
          <input
            type="tel"
            placeholder="Phone Number (10 digits)"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
            onMouseEnter={() => handleSpeak("Phone number field")}
            maxLength="10"
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onMouseEnter={() => handleSpeak("Password field")}
            required
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Admin Secret Key (Default: ADMIN123)"
            value={adminSecretKey}
            onChange={(e) => setAdminSecretKey(e.target.value)}
            onMouseEnter={() => handleSpeak("Admin secret key field")}
            required
            style={styles.input}
          />
          <button
            type="submit"
            style={styles.button}
            onMouseEnter={() => handleSpeak("Register Admin Account button")}
          >
            Register Admin Account
          </button>
        </form>
      </div>
    </div>
  );
};

const styles = {
  container: { minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: "#05070d", fontFamily: "system-ui" },
  card: { width: "100%", maxWidth: "420px", padding: "30px", backgroundColor: "#0a0d18", borderRadius: "12px", border: "1px solid #141a2e", color: "#fff" },
  title: { textAlign: "center", color: "#60a5fa", marginBottom: "20px" },
  errorBox: { backgroundColor: "#991b1b", color: "#f87171", padding: "10px", borderRadius: "8px", marginBottom: "14px", fontSize: "13px" },
  successBox: { backgroundColor: "#166534", color: "#4ade80", padding: "10px", borderRadius: "8px", marginBottom: "14px", fontSize: "13px" },
  form: { display: "flex", flexDirection: "column", gap: "12px" },
  input: { padding: "12px", backgroundColor: "#060810", border: "1px solid #1d4ed8", borderRadius: "8px", color: "#fff", outline: "none" },
  button: { padding: "12px", backgroundColor: "#1d4ed8", color: "#fff", border: "none", borderRadius: "8px", fontWeight: "bold", cursor: "pointer", marginTop: "10px" },
};

export default AdminRegistration;