import React, { useState } from "react";
import { speakText } from "../utils/languages";

const sampleQuestions = [
  {
    id: 1,
    subject: "Web Development",
    question: "Which HTML element is used to define an unordered list?",
    options: ["<ol>", "<ul>", "<li>", "<list>"],
    answer: "<ul>",
  },
  {
    id: 2,
    subject: "Web Development",
    question: "What is the primary purpose of the 'alt' attribute on an image tag?",
    options: [
      "To specify image source URL",
      "To style image border",
      "To provide alternative text for screen readers",
      "To set image dimensions",
    ],
    answer: "To provide alternative text for screen readers",
  },
  {
    id: 3,
    subject: "Database",
    question: "Which Mongoose method is used to create and save a document in a single step?",
    options: ["Model.find()", "Model.create()", "Model.update()", "Model.insertOne()"],
    answer: "Model.create()",
  },
  {
    id: 4,
    subject: "Voice API",
    question: "Which Web API is used for text-to-speech conversion in modern browsers?",
    options: [
      "SpeechRecognition",
      "SpeechSynthesisUtterance",
      "getUserMedia",
      "AudioContext",
    ],
    answer: "SpeechSynthesisUtterance",
  },
];

const ExamCreation = () => {
  const [questions, setQuestions] = useState(sampleQuestions);
  const [selectedAnswers, setSelectedAnswers] = useState({});

  const handleSpeak = (text) => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    speakText(text, "en-US");
  };

  const handleOptionSelect = (qId, option) => {
    setSelectedAnswers((prev) => ({ ...prev, [qId]: option }));
    handleSpeak(`Selected option ${option}`);
  };

  return (
    <div style={styles.container}>
      <h2
        style={styles.title}
        onMouseEnter={() => handleSpeak("Online Exam Module")}
      >
        📝 Practice Exam Module
      </h2>

      {questions.map((q, index) => (
        <div
          key={q.id}
          style={styles.questionCard}
          onMouseEnter={() =>
            handleSpeak(
              `Question ${index + 1}: ${q.question}. Options are: ${q.options.join(", ")}`
            )
          }
        >
          <div style={styles.badge}>{q.subject}</div>
          <h3 style={styles.questionText}>
            Q{index + 1}. {q.question}
          </h3>

          <div style={styles.optionsContainer}>
            {q.options.map((opt, i) => (
              <label
                key={i}
                style={{
                  ...styles.optionLabel,
                  backgroundColor:
                    selectedAnswers[q.id] === opt ? "#1d4ed8" : "#060810",
                }}
                onMouseEnter={() => handleSpeak(`Option ${i + 1}: ${opt}`)}
              >
                <input
                  type="radio"
                  name={`question-${q.id}`}
                  value={opt}
                  checked={selectedAnswers[q.id] === opt}
                  onChange={() => handleOptionSelect(q.id, opt)}
                  style={{ marginRight: "10px" }}
                />
                {opt}
              </label>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: "600px",
    margin: "0 auto",
    padding: "20px",
    fontFamily: "system-ui, sans-serif",
    color: "#e2e8f0",
  },
  title: {
    textAlign: "center",
    color: "#60a5fa",
    marginBottom: "20px",
  },
  questionCard: {
    backgroundColor: "#0a0d18",
    border: "1px solid #141a2e",
    borderRadius: "12px",
    padding: "20px",
    marginBottom: "16px",
  },
  badge: {
    display: "inline-block",
    padding: "4px 8px",
    fontSize: "12px",
    backgroundColor: "#1e293b",
    color: "#94a3b8",
    borderRadius: "6px",
    marginBottom: "10px",
  },
  questionText: {
    fontSize: "16px",
    color: "#f8fafc",
    marginBottom: "14px",
  },
  optionsContainer: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  optionLabel: {
    padding: "10px 14px",
    borderRadius: "8px",
    border: "1px solid #1e293b",
    cursor: "pointer",
    fontSize: "14px",
    display: "flex",
    alignItems: "center",
  },
};

export default ExamCreation;