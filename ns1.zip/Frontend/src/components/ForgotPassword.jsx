import React, { useState, useRef, useEffect } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { Eye, EyeOff, CheckCircle, Mic, Lock, Mail, Key, ShieldCheck, ArrowLeft } from "lucide-react";
import { speakIn, cancelSpeech } from "./speech";
import ProjectLogo from "./ProjectLogo.jsx";

export default function ForgotPassword() {
  const navigate = useNavigate();
  const location = useLocation();

  // Pre-select role if navigated from login role selection (defaults to teacher or student)
  const initialRole = location.state?.role || "student";

  const [role, setRole] = useState(initialRole);
  const [step, setStep] = useState(1); // For Teachers: 1 = Send OTP, 2 = Verify OTP & Reset
  const [email, setEmail] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [enteredOtp, setEnteredOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [infoMessage, setInfoMessage] = useState("");

  const emailInputRef = useRef(null);
  const otpInputRef = useRef(null);
  const passwordInputRef = useRef(null);
  const recognitionRef = useRef(null);

  const stopRecognition = () => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
    }
  };

  const speak = (text, onEndCallback = null) => {
    stopRecognition();
    speakIn(text, 'en-US', { onEnd: onEndCallback });
  };

  useEffect(() => {
    if (role === 'teacher') {
      speak("Teacher password recovery. Please enter your Gmail address to receive your OTP code.");
    } else {
      speak("Student password recovery page. Enter your email and new password to reset.");
    }
    return () => cancelSpeech();
  }, [role]);

  // Handler for Teachers: Stage 1 Send OTP
  const handleTeacherSendOtp = (e) => {
    if (e) e.preventDefault();
    setErrorMessage("");
    setInfoMessage("");

    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      const msg = "Please enter a valid Gmail address.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    const code = String(Math.floor(100000 + Math.random() * 900000));
    setGeneratedOtp(code);
    setStep(2);

    setInfoMessage(`📩 6-Digit OTP sent to ${email}! (Demo Code: ${code})`);
    speak(`OTP code sent to your Gmail address ${email}. Please enter your 6 digit OTP code.`);
  };

  // Handler for Teachers: Stage 2 Verify OTP & Reset
  const handleTeacherVerifyAndReset = (e) => {
    if (e) e.preventDefault();
    setErrorMessage("");

    if (!enteredOtp || enteredOtp.trim() !== generatedOtp) {
      const msg = "Invalid OTP code. Please enter the correct 6-digit OTP code.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    if (!newPassword || newPassword.length < 6) {
      const msg = "New password must be at least 6 characters long.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    if (newPassword !== confirmPassword) {
      const msg = "Passwords do not match.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    setShowSuccessPopup(true);
    speak("OTP verified! Teacher password updated successfully. Click to proceed to login.");
  };

  // Handler for Students & Admins: Direct Reset (As before)
  const handleDirectReset = (e) => {
    if (e) e.preventDefault();
    setErrorMessage("");

    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      const msg = "Please enter a valid email address.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    if (!newPassword || newPassword.length < 6) {
      const msg = "New password must be at least 6 characters long.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    if (newPassword !== confirmPassword) {
      const msg = "Passwords do not match. Please re-enter.";
      setErrorMessage(msg);
      speak(msg);
      return;
    }

    setShowSuccessPopup(true);
    speak(`Password updated successfully for ${role}! Say OK or click to proceed to login.`);
  };

  // Voice Assistant speech recognition
  const startVoiceAssist = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    stopRecognition();
    cancelSpeech();

    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = 'en-US';
    recognition.continuous = false;

    recognition.onstart = () => {
      setIsListening(true);
      speak("Voice assistant listening clearly. Speak your email address or password now.");
    };

    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript.toLowerCase().trim();
      setIsListening(false);
      const cleanEmail = transcript.replace(/\s+at\s+/g, "@").replace(/\s+dot\s+/g, ".").replace(/\s+/g, "");

      if (cleanEmail.includes("@")) {
        setEmail(cleanEmail);
        speak(`Recognized email ${cleanEmail}.`);
      } else {
        speak(`Voice captured: ${transcript}`);
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    try { recognition.start(); } catch (e) {}
  };

  const handleModalClose = () => {
    setShowSuccessPopup(false);
    cancelSpeech();
    navigate("/login", { state: { role } });
  };

  return (
    <div
      onClick={startVoiceAssist}
      style={{
        minHeight: "100vh", background: "#f0f9ff", display: "flex", flexDirection: "column",
        justifyContent: "center", alignItems: "center", padding: "24px", boxSizing: "border-box"
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%", maxWidth: "480px", background: "#ffffff", border: "1px solid #bae6fd",
          padding: "36px 32px", borderRadius: "24px", boxShadow: "0 20px 40px -15px rgba(2, 132, 199, 0.15)", boxSizing: "border-box"
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: "20px" }}>
          <ProjectLogo size="large" />
          <p style={{ fontSize: "13px", color: "#0369a1", margin: "6px 0 0 0", fontWeight: "700" }}>
            Accessible Password Recovery
          </p>
        </div>

        {/* Voice Indicator */}
        <div style={{
          padding: "10px 14px", borderRadius: "12px", background: "#e0f2fe",
          border: "1px solid #7dd3fc", marginBottom: "20px", display: "flex", alignItems: "center", gap: "10px"
        }}>
          <Mic size={18} color={isListening ? "#ef4444" : "#0284c7"} />
          <span style={{ fontSize: "12px", color: "#0369a1", fontWeight: "600" }}>
            {isListening ? "Listening… speak now" : "Tap screen anywhere to start voice guide."}
          </span>
        </div>

        {/* Error / Info Banners */}
        {errorMessage && (
          <div style={{ background: "#fef2f2", border: "1px solid #fca5a5", color: "#dc2626", padding: "10px 14px", borderRadius: "10px", fontSize: "13px", marginBottom: "16px", fontWeight: "700", textAlign: "center" }}>
            ⚠️ {errorMessage}
          </div>
        )}

        {infoMessage && role === 'teacher' && (
          <div style={{ background: "#f0fdf4", border: "1px solid #86efac", color: "#166534", padding: "10px 14px", borderRadius: "10px", fontSize: "13px", marginBottom: "16px", fontWeight: "700", textAlign: "center" }}>
            {infoMessage}
          </div>
        )}

        {/* Role Selector */}
        <div style={{ marginBottom: "20px" }}>
          <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "8px" }}>
            Account Role
          </label>
          <div style={{ display: "flex", gap: "8px" }}>
            {[
              { id: "student", label: "Student", icon: "🎓" },
              { id: "teacher", label: "Teacher", icon: "👨‍🏫" },
              { id: "admin", label: "Admin", icon: "🛡️" }
            ].map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => {
                  setRole(r.id);
                  setStep(1);
                  setErrorMessage("");
                  setInfoMessage("");
                }}
                style={{
                  flex: 1, padding: "10px 4px", borderRadius: "10px",
                  border: role === r.id ? "2px solid #0284c7" : "1px solid #bae6fd",
                  backgroundColor: role === r.id ? "#0284c7" : "#f0f9ff",
                  color: role === r.id ? "#ffffff" : "#0369a1", fontWeight: "700", fontSize: "12px", cursor: "pointer"
                }}
              >
                {r.icon} {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* --- TEACHER FLOW (WITH OTP) --- */}
        {role === "teacher" ? (
          step === 1 ? (
            /* Teacher Stage 1: Gmail & Send OTP */
            <form onSubmit={handleTeacherSendOtp} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              <div>
                <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                  Teacher Gmail Address
                </label>
                <div style={{ position: "relative" }}>
                  <Mail size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                  <input
                    ref={emailInputRef}
                    type="email"
                    placeholder="e.g. teacher@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    style={inputStyle}
                    required
                  />
                </div>
                <span style={{ fontSize: "11px", color: "#64748b", marginTop: "4px", display: "block" }}>
                  A 6-digit OTP code will be sent to your Gmail inbox.
                </span>
              </div>

              <button
                type="submit"
                style={{
                  width: "100%", padding: "14px", borderRadius: "12px",
                  backgroundColor: "#0284c7", color: "#ffffff", fontWeight: "700",
                  fontSize: "15px", border: "none", cursor: "pointer", marginTop: "6px",
                  boxShadow: "0 4px 12px rgba(2, 132, 199, 0.3)",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: "8px"
                }}
              >
                <ShieldCheck size={18} /> Send OTP to Gmail
              </button>
            </form>
          ) : (
            /* Teacher Stage 2: Enter OTP & New Password */
            <form onSubmit={handleTeacherVerifyAndReset} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
              <div style={{ background: "#f0f9ff", padding: "12px", borderRadius: "10px", border: "1px solid #bae6fd", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: "12px", color: "#0369a1", fontWeight: "700" }}>
                  📧 OTP Sent to: <strong>{email}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  style={{ background: "none", border: "none", color: "#0284c7", fontSize: "11px", fontWeight: "800", cursor: "pointer", textDecoration: "underline" }}
                >
                  Change Email
                </button>
              </div>

              {/* OTP Field */}
              <div>
                <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                  Enter 6-Digit OTP Code
                </label>
                <div style={{ position: "relative" }}>
                  <Key size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                  <input
                    ref={otpInputRef}
                    type="text"
                    maxLength="6"
                    placeholder="Enter 6-digit OTP (e.g. 849201)"
                    value={enteredOtp}
                    onChange={(e) => setEnteredOtp(e.target.value)}
                    style={{ ...inputStyle, letterSpacing: "2px", fontWeight: "bold" }}
                    required
                  />
                </div>
              </div>

              {/* New Password */}
              <div>
                <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                  New Password
                </label>
                <div style={{ position: "relative" }}>
                  <Lock size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                  <input
                    ref={passwordInputRef}
                    type={showPassword ? "text" : "password"}
                    placeholder="New Password (min 6 chars)"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    style={{ ...inputStyle, paddingRight: "44px" }}
                    required
                  />
                  <button
                    type="button" onClick={() => setShowPassword(!showPassword)}
                    style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "#64748b" }}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                  Confirm New Password
                </label>
                <div style={{ position: "relative" }}>
                  <Lock size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Confirm New Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    style={{ ...inputStyle, paddingRight: "44px" }}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                style={{
                  width: "100%", padding: "14px", borderRadius: "12px",
                  backgroundColor: "#0284c7", color: "#ffffff", fontWeight: "700",
                  fontSize: "15px", border: "none", cursor: "pointer", marginTop: "6px",
                  boxShadow: "0 4px 12px rgba(2, 132, 199, 0.3)"
                }}
              >
                Verify OTP & Reset Password
              </button>
            </form>
          )
        ) : (
          /* --- STUDENT & ADMIN FLOW (DIRECT RESET AS BEFORE) --- */
          <form onSubmit={handleDirectReset} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            <div>
              <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                Registered Email Address
              </label>
              <div style={{ position: "relative" }}>
                <Mail size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                <input
                  ref={emailInputRef}
                  type="email"
                  placeholder="Registered Email Address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={inputStyle}
                  required
                />
              </div>
            </div>

            <div>
              <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                New Password
              </label>
              <div style={{ position: "relative" }}>
                <Lock size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                <input
                  ref={passwordInputRef}
                  type={showPassword ? "text" : "password"}
                  placeholder="New Password (min 6 chars)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  style={{ ...inputStyle, paddingRight: "44px" }}
                  required
                />
                <button
                  type="button" onClick={() => setShowPassword(!showPassword)}
                  style={{ position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "#64748b" }}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div>
              <label style={{ fontSize: "12px", color: "#0369a1", fontWeight: "800", display: "block", marginBottom: "6px" }}>
                Confirm New Password
              </label>
              <div style={{ position: "relative" }}>
                <Lock size={18} color="#0284c7" style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)" }} />
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Confirm New Password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  style={{ ...inputStyle, paddingRight: "44px" }}
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              style={{
                width: "100%", padding: "14px", borderRadius: "12px",
                backgroundColor: "#0284c7", color: "#ffffff", fontWeight: "700",
                fontSize: "15px", border: "none", cursor: "pointer", marginTop: "6px",
                boxShadow: "0 4px 12px rgba(2, 132, 199, 0.3)"
              }}
            >
              Update Password
            </button>
          </form>
        )}

        <div style={{ display: "flex", justifyContent: "space-between", marginTop: "16px", flexWrap: "wrap", gap: "8px" }}>
          <Link to="/login" style={{ fontSize: "13px", color: "#0284c7", textDecoration: "none", fontWeight: "600", display: "inline-flex", alignItems: "center", gap: "4px" }}>
            <ArrowLeft size={14} /> Back to Login
          </Link>
          <Link to="/home" style={{ fontSize: "13px", color: "#475569", textDecoration: "none", fontWeight: "600" }}>
            Go to Home Page →
          </Link>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccessPopup && (
        <div style={{ position: "fixed", inset: 0, backgroundColor: "rgba(2, 132, 199, 0.25)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 1000, backdropFilter: "blur(4px)" }}>
          <div style={{ background: "#ffffff", border: "2px solid #0284c7", padding: "32px", borderRadius: "24px", textAlign: "center", maxWidth: "380px", width: "100%", boxShadow: "0 20px 40px rgba(0,0,0,0.15)" }}>
            <CheckCircle size={48} color="#22c55e" style={{ marginBottom: "16px" }} />
            <h2 style={{ fontSize: "20px", color: "#0f172a", marginBottom: "8px", fontWeight: "800" }}>Password Updated!</h2>
            <p style={{ fontSize: "14px", color: "#475569", marginBottom: "20px" }}>Your {role} account password has been successfully updated. Click below to login.</p>
            <button type="button" onClick={handleModalClose} style={{ width: "100%", padding: "12px", borderRadius: "12px", backgroundColor: "#0284c7", color: "#fff", border: "none", fontWeight: "700", cursor: "pointer" }}>
              Proceed to Login
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const inputStyle = {
  width: "100%",
  padding: "14px 14px 14px 42px",
  borderRadius: "12px",
  fontSize: "14px",
  outline: "none",
  boxSizing: "border-box",
  backgroundColor: "#ffffff",
  color: "#0f172a",
  border: "1px solid #bae6fd",
};