import React from 'react';

// GlobalVoiceAssistant - ElevenLabs voice engine is used silently in code via speech.js without rendering any visible UI box on screen.
export default function GlobalVoiceAssistant() {
  return null;
}