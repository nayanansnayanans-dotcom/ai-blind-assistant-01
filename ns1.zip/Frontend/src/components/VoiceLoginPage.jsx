import React, { useState, useRef } from 'react';
import { Eye, EyeOff, CheckCircle, Mic, Lock, Mail } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { speakIn, cancelSpeech } from './speech';
import ProjectLogo from './ProjectLogo.jsx';

const BASE_SYMBOLS = [
  [/\b(at the rate of|at sign|at)\b/g, '@'],
  [/\b(dot|point|period)\b/g, '.'],
  [/\b(underscore)\b/g, '_'],
  [/\b(dash|hyphen)\b/g, '-'],
];

const DIGIT_MAP = {
  'zero': '0', 'one': '1', 'two': '2', 'three': '3', 'four': '4',
  'five': '5', 'six': '6', 'seven': '7', 'eight': '8', 'nine': '9'
};
const toAsciiDigits = (s) => s.replace(/[०-९]/g, (d) => DIGIT_MAP[d] || d);

const inputStyle = {
  width: '100%',
  padding: '14px 14px 14px 42px',
  borderRadius: '12px',
  fontSize: '14px',
  outline: 'none',
  boxSizing: 'border-box',
  backgroundColor: '#ffffff',
  color: '#0f172a',
  border: '1px solid #bae6fd',
};

export default function VoiceLoginPage() {
  const navigate = useNavigate();

  const [role, setRole] = useState('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [activeField, setActiveField] = useState(null);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);

  const emailRefInput = useRef(null);
  const passwordRefInput = useRef(null);

  const roleRef = useRef('student');
  const emailRef = useRef('');
  const passwordRef = useRef('');
  const recognitionRef = useRef(null);
  const pendingStepRef = useRef(null);

  const strings = {
    welcome: 'Welcome to VisionAssist AI. Accessible Voice and Tap Assistant. Please select your role to login.',
    rolePrompt: 'Please speak your role: Student, Teacher, or Admin.',
    emailPrompt: 'Please speak your registered email address.',
    invalidEmail: 'Invalid email address. Please speak your email address again.',
    passwordPrompt: 'Please speak your password.',
    emptyEmail: 'Email address cannot be empty. Please speak your email address.',
    emptyPassword: 'Password cannot be empty. Please speak your password.',
    success: (roleName) => `Login completed successfully as ${roleName}. Say OK to enter dashboard.`,
  };

  const rolesDisplay = { student: 'Student', teacher: 'Teacher', other: 'Admin' };
  const roleWords = {
    student: ['student', 'learner', 'pupil'],
    teacher: ['teacher', 'faculty', 'professor', 'instructor'],
    other: ['admin', 'administrator', 'system admin', 'guest']
  };

  const stopRecognition = () => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
    }
  };

  const speak = (text, onEndCallback = null) => {
    stopRecognition();
    speakIn(text, 'en-US', { onEnd: onEndCallback });
  };

  const updateRole = (newRole) => {
    setRole(newRole);
    roleRef.current = newRole;
  };

  const updateField = (field, val) => {
    if (field === 'role') { updateRole(val); }
    if (field === 'email') { setEmail(val); emailRef.current = val; }
    if (field === 'password') { setPassword(val); passwordRef.current = val; }
  };

  const handleTapToStart = () => {
    if (showSuccessPopup) return;
    speak(strings.welcome, () => startGuidedFlow('role'));
  };

  const startGuidedFlow = (step) => {
    setActiveField(step);

    if (step === 'role') {
      speak(strings.rolePrompt, () => listenForInput('role'));
    } else if (step === 'email') {
      emailRefInput.current?.focus();
      speak(strings.emailPrompt, () => listenForInput('email'));
    } else if (step === 'password') {
      passwordRefInput.current?.focus();
      speak(strings.passwordPrompt, () => listenForInput('password'));
    }
  };

  const confirmFieldValue = (fieldKey, displayVal, nextStep) => {
    pendingStepRef.current = { fieldKey, nextStep, displayVal };
    speak(`You entered ${displayVal}. Is this correct? Say yes or no.`, () => listenForConfirmationYesNo());
  };

  const listenForConfirmationYesNo = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    stopRecognition();
    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = 'en-US';
    recognition.continuous = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript.toLowerCase().trim();
      const isYes = ['yes', 'correct', 'yeah', 'yep', 'right', 'sure'].some(w => transcript.includes(w));
      const isNo = ['no', 'incorrect', 'wrong', 'change'].some(w => transcript.includes(w));

      if (isYes) {
        const next = pendingStepRef.current?.nextStep;
        if (next === 'submit') {
          validateAndSubmit();
        } else if (next) {
          startGuidedFlow(next);
        }
      } else if (isNo) {
        const fieldToRetry = pendingStepRef.current?.fieldKey;
        if (fieldToRetry) {
          if (fieldToRetry === 'role') updateRole('student');
          if (fieldToRetry === 'email') updateField('email', '');
          if (fieldToRetry === 'password') updateField('password', '');
          
          speak(`Let's re-enter. Please speak again.`, () => startGuidedFlow(fieldToRetry));
        }
      } else {
        speak(`Please say yes or no to confirm.`, () => listenForConfirmationYesNo());
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    try { recognition.start(); } catch (e) {}
  };

  const formatSpeech = (transcript, targetField) => {
    let clean = toAsciiDigits(transcript.trim());

    if (targetField === 'email') {
      clean = clean.toLowerCase();
      BASE_SYMBOLS.forEach(([re, rep]) => {
        clean = clean.replace(re, rep);
      });
      clean = clean.replace(/\s+/g, '');
    } else if (targetField === 'password') {
      clean = clean.replace(/\s+/g, '');
    }
    return clean;
  };

  const listenForInput = (targetField) => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    stopRecognition();

    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);

    recognition.onresult = (e) => {
      const rawTranscript = e.results[0][0].transcript;
      const lower = rawTranscript.toLowerCase().trim();

      if (targetField === 'role') {
        let chosenRole = 'student';
        if (roleWords.teacher.some((w) => lower.includes(w))) chosenRole = 'teacher';
        else if (roleWords.other.some((w) => lower.includes(w))) chosenRole = 'other';

        updateRole(chosenRole);
        confirmFieldValue('role', rolesDisplay[chosenRole], 'email');
      } else if (targetField === 'email') {
        const formattedEmail = formatSpeech(rawTranscript, 'email');
        updateField('email', formattedEmail);
        confirmFieldValue('email', formattedEmail, 'password');
      } else if (targetField === 'password') {
        const formattedPwd = formatSpeech(rawTranscript, 'password');
        updateField('password', formattedPwd);
        setActiveField(null);
        confirmFieldValue('password', 'your password', 'submit');
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    try { recognition.start(); } catch (e) {}
  };

  const listenForOkConfirmation = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    stopRecognition();

    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = 'en-US';
    recognition.continuous = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript.toLowerCase().trim();
      const accepted = ['ok', 'okay', 'confirm', 'yes'];
      if (accepted.some((w) => transcript.includes(w))) handleModalClose();
      else listenForOkConfirmation();
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    try { recognition.start(); } catch (e) {}
  };

  const validateAndSubmit = () => {
    const emailVal = emailRef.current || email;
    const pwdVal = passwordRef.current || password;

    if (!emailVal || !/\S+@\S+\.\S+/.test(emailVal)) {
      speak(strings.invalidEmail, () => startGuidedFlow('email'));
      return;
    }
    if (!pwdVal) {
      speak(strings.emptyPassword, () => startGuidedFlow('password'));
      return;
    }

    setShowSuccessPopup(true);
    speak(strings.success(rolesDisplay[roleRef.current]), () => listenForOkConfirmation());
  };

  const handleModalClose = () => {
    setShowSuccessPopup(false);
    cancelSpeech();
    stopRecognition();

    const session = {
      role: roleRef.current,
      email: emailRef.current || email,
      isAuthenticated: true,
    };
    localStorage.setItem('auth_session', JSON.stringify(session));

    // Route based on selected user role
    if (roleRef.current === 'teacher') {
      navigate('/teacher-dashboard');
    } else if (roleRef.current === 'other') {
      navigate('/admin-dashboard');
    } else {
      navigate('/dashboard');
    }
  };

  return (
    <div
      onClick={handleTapToStart}
      style={{
        minHeight: '100vh', background: '#f0f9ff', display: 'flex', flexDirection: 'column',
        justifyContent: 'center', alignItems: 'center', padding: '24px', cursor: 'pointer', boxSizing: 'border-box'
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: '460px', background: '#ffffff', border: '1px solid #bae6fd',
          padding: '40px 36px', borderRadius: '24px', boxShadow: '0 20px 40px -15px rgba(2, 132, 199, 0.12)', boxSizing: 'border-box'
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '24px' }}>
          <ProjectLogo size="large" />
          <p style={{ fontSize: '13px', color: '#475569', margin: '8px 0 0 0', fontWeight: '600' }}>Accessible Voice & Tap Assistant - Please Login</p>
        </div>

        <div style={{
          padding: '12px 16px', borderRadius: '12px', background: '#e0f2fe',
          border: '1px solid #7dd3fc', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '10px'
        }}>
          <Mic size={18} color={isListening ? '#ef4444' : '#0284c7'} />
          <span style={{ fontSize: '13px', color: '#0369a1', fontWeight: '600' }}>
            {isListening ? 'Listening… speak now' : 'Tap anywhere to start voice guide.'}
          </span>
        </div>

        {/* Form Fields & Controls */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label style={{ fontSize: '12px', color: '#475569', fontWeight: '700', display: 'block', marginBottom: '8px' }}>Login Role</label>
            <div style={{ display: 'flex', gap: '8px' }}>
              {[{ id: 'student', label: 'Student', icon: '🎓' }, { id: 'teacher', label: 'Teacher', icon: '👨‍🏫' }, { id: 'other', label: 'Admin', icon: '🛡️' }].map((r) => (
                <button
                  key={r.id} type="button" onClick={() => updateRole(r.id)}
                  style={{
                    flex: 1, padding: '10px 4px', borderRadius: '10px',
                    border: role === r.id ? '2px solid #0284c7' : '1px solid #bae6fd',
                    backgroundColor: role === r.id ? '#0284c7' : '#f0f9ff',
                    color: role === r.id ? '#ffffff' : '#0369a1', fontWeight: '700', fontSize: '12px', cursor: 'pointer'
                  }}
                >
                  {r.icon} {r.label}
                </button>
              ))}
            </div>
          </div>

          <div style={{ position: 'relative' }}>
            <Mail size={18} color={activeField === 'email' ? '#0284c7' : '#64748b'} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              ref={emailRefInput} type="email" placeholder="name@email.com" value={email}
              onChange={(e) => updateField('email', e.target.value)}
              style={{ ...inputStyle, border: activeField === 'email' ? '2px solid #0284c7' : '1px solid #bae6fd' }}
            />
          </div>

          <div style={{ position: 'relative' }}>
            <Lock size={18} color={activeField === 'password' ? '#0284c7' : '#64748b'} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              ref={passwordRefInput} type={showPassword ? 'text' : 'password'} placeholder="••••••••" value={password}
              onChange={(e) => updateField('password', e.target.value)}
              style={{ ...inputStyle, paddingRight: '44px', border: activeField === 'password' ? '2px solid #0284c7' : '1px solid #bae6fd' }}
            />
            <button
              type="button" onClick={() => setShowPassword(!showPassword)}
              style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>

          <div style={{ textAlign: 'right', marginTop: '-4px' }}>
            <Link to="/forgot-password" state={{ role }} style={{ fontSize: '13px', color: '#0284c7', textDecoration: 'none', fontWeight: '600' }}>
              Forgot Password?
            </Link>
          </div>

          <button
            type="button" onClick={validateAndSubmit}
            style={{ width: '100%', padding: '14px', borderRadius: '12px', backgroundColor: '#0284c7', color: '#ffffff', fontWeight: '700', fontSize: '15px', border: 'none', cursor: 'pointer', marginTop: '4px', boxShadow: '0 4px 12px rgba(2, 132, 199, 0.3)' }}
          >
            Login
          </button>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '12px', flexWrap: 'wrap', gap: '8px' }}>
            <Link to="/register" style={{ fontSize: '13px', color: '#0284c7', textDecoration: 'none', fontWeight: '600' }}>Don't have an account? Register here</Link>
            <Link to="/home" style={{ fontSize: '13px', color: '#475569', textDecoration: 'none', fontWeight: '600' }}>Go to Home Page →</Link>
          </div>
        </div>
      </div>

      {showSuccessPopup && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(2, 132, 199, 0.25)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000, backdropFilter: 'blur(4px)' }}>
          <div style={{ background: '#ffffff', border: '2px solid #0284c7', padding: '32px', borderRadius: '24px', textAlign: 'center', maxWidth: '380px', width: '100%', boxShadow: '0 20px 40px rgba(0,0,0,0.15)' }}>
            <CheckCircle size={48} color="#22c55e" style={{ marginBottom: '16px' }} />
            <h2 style={{ fontSize: '20px', color: '#0f172a', marginBottom: '8px', fontWeight: '800' }}>Login Successful!</h2>
            <p style={{ fontSize: '14px', color: '#475569', marginBottom: '20px' }}>Say "OK" or click below to enter dashboard.</p>
            <button type="button" onClick={handleModalClose} style={{ width: '100%', padding: '12px', borderRadius: '12px', backgroundColor: '#0284c7', color: '#fff', border: 'none', fontWeight: '700', cursor: 'pointer' }}>
              Enter Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}