import React, { useState, useEffect } from 'react';
import { getElevenLabsConfig, saveElevenLabsConfig, ELEVENLABS_VOICES, speakWithElevenLabs } from '../services/elevenlabs';
import { speakIn } from './speech';

export default function ElevenLabsSettings({ isOpen, onClose }) {
  const [apiKey, setApiKey] = useState('');
  const [voiceId, setVoiceId] = useState('21m00Tcm4TlvDq8ikWAM');
  const [enabled, setEnabled] = useState(true);
  const [isTesting, setIsTesting] = useState(false);
  const [savedMessage, setSavedMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      const config = getElevenLabsConfig();
      setApiKey(config.apiKey);
      setVoiceId(config.voiceId);
      setEnabled(config.enabled);
      setSavedMessage('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = (e) => {
    e.preventDefault();
    saveElevenLabsConfig({ apiKey: apiKey.trim(), voiceId, enabled });
    setSavedMessage('ElevenLabs Voice Settings saved successfully!');
    speakIn('ElevenLabs settings saved successfully!');
    setTimeout(() => setSavedMessage(''), 4000);
  };

  const handleTestVoice = async () => {
    setIsTesting(true);
    // Temporarily save to test
    saveElevenLabsConfig({ apiKey: apiKey.trim(), voiceId, enabled: true });
    
    const sampleText = "Hello! I am your ElevenLabs voice assistant. I hear and speak clearly for blind students.";
    const success = await speakWithElevenLabs(sampleText, { voiceId });
    
    if (!success) {
      speakIn("Testing fallback voice. ElevenLabs API key is either missing or invalid.");
    }
    setIsTesting(false);
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(15, 23, 42, 0.65)',
      display: 'grid',
      placeItems: 'center',
      zIndex: 9999,
      backdropFilter: 'blur(4px)',
      padding: '20px'
    }}>
      <div style={{
        background: '#ffffff',
        borderRadius: '16px',
        maxWidth: '520px',
        width: '100%',
        padding: '28px',
        boxShadow: '0 20px 25px -5px rgba(2, 132, 199, 0.2), 0 8px 10px -6px rgba(2, 132, 199, 0.1)',
        border: '2px solid #bae6fd',
        color: '#0f172a'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 style={{ margin: 0, color: '#0369a1', fontSize: '1.4rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
            ⚡ ElevenLabs Voice Assistant
          </h2>
          <button 
            type="button" 
            onClick={onClose}
            style={{
              background: '#f0f9ff',
              border: '1px solid #bae6fd',
              borderRadius: '50%',
              width: '32px',
              height: '32px',
              fontSize: '1.2rem',
              cursor: 'pointer',
              color: '#0369a1'
            }}
          >×</button>
        </div>

        <form onSubmit={handleSave} style={{ display: 'grid', gap: '16px' }}>
          <div style={{ background: '#f0f9ff', padding: '12px 16px', borderRadius: '10px', border: '1px solid #e0f2fe' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '10px', fontWeight: 'bold', color: '#0369a1', cursor: 'pointer' }}>
              <input 
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                style={{ width: '18px', height: '18px', accentColor: '#0284c7' }}
              />
              Enable ElevenLabs AI Voice Output
            </label>
            <p style={{ margin: '4px 0 0 28px', fontSize: '0.85rem', color: '#64748b' }}>
              Provides ultra-realistic, clear enunciation. Automatically falls back to browser voice if offline.
            </p>
          </div>

          <div>
            <label style={{ display: 'block', fontWeight: 'bold', marginBottom: '6px', color: '#0369a1', fontSize: '0.9rem' }}>
              ElevenLabs API Key
            </label>
            <input 
              type="password"
              placeholder="e.g. sk_1234567890abcdef..."
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 14px',
                borderRadius: '8px',
                border: '1px solid #bae6fd',
                fontSize: '0.95rem',
                boxSizing: 'border-box',
                outlineColor: '#0284c7'
              }}
            />
            <span style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '4px', display: 'block' }}>
              Optional. If left empty, backend server key or browser fallback voice will be used.
            </span>
          </div>

          <div>
            <label style={{ display: 'block', fontWeight: 'bold', marginBottom: '6px', color: '#0369a1', fontSize: '0.9rem' }}>
              Select ElevenLabs Voice Character
            </label>
            <select
              value={voiceId}
              onChange={(e) => setVoiceId(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 14px',
                borderRadius: '8px',
                border: '1px solid #bae6fd',
                fontSize: '0.95rem',
                backgroundColor: '#ffffff',
                color: '#0369a1',
                fontWeight: '600',
                boxSizing: 'border-box'
              }}
            >
              {ELEVENLABS_VOICES.map((v) => (
                <option key={v.id} value={v.id}>
                  🎙️ {v.name} ({v.gender}) - {v.description}
                </option>
              ))}
            </select>
          </div>

          {savedMessage && (
            <div style={{ background: '#dcfce7', color: '#166534', padding: '10px', borderRadius: '8px', fontSize: '0.9rem', textAlign: 'center' }}>
              ✅ {savedMessage}
            </div>
          )}

          <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
            <button
              type="button"
              onClick={handleTestVoice}
              disabled={isTesting}
              style={{
                flex: 1,
                padding: '11px',
                background: '#e0f2fe',
                color: '#0369a1',
                border: '1px solid #bae6fd',
                borderRadius: '8px',
                fontWeight: 'bold',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px'
              }}
            >
              {isTesting ? '🔊 Playing...' : '🎧 Test Voice'}
            </button>

            <button
              type="submit"
              style={{
                flex: 1,
                padding: '11px',
                background: '#0284c7',
                color: '#ffffff',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}
            >
              Save Settings
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
