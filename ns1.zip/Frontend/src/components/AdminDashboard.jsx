import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Eye, Mic, Settings, LogOut, ShieldCheck, Mail, DollarSign } from 'lucide-react';
import { speakIn, cancelSpeech } from './speech';
import ProjectLogo from './ProjectLogo.jsx';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('users');
  const [isListening, setIsListening] = useState(false);
  const [lastCommand, setLastCommand] = useState('');

  const [users, setUsers] = useState([
    { id: 1, name: 'Alex Johnson', email: 'alex@gmail.com', role: 'Student' },
    { id: 2, name: 'Prof. Robert Davis', email: 'robert@gmail.com', role: 'Teacher' },
    { id: 3, name: 'System Admin', email: 'admin@gmail.com', role: 'Admin' }
  ]);

  const [currencyLogs, setCurrencyLogs] = useState([
    { id: 1, currency: '100 INR Note', confidence: '98.5%', timestamp: 'Today, 10:45 AM' },
    { id: 2, currency: '500 INR Note', confidence: '99.1%', timestamp: 'Today, 09:15 AM' },
    { id: 3, currency: '50 INR Note', confidence: '97.4%', timestamp: 'Yesterday, 04:30 PM' }
  ]);

  const handleLogout = () => {
    cancelSpeech();
    localStorage.removeItem('auth_session');
    navigate('/login');
  };

  // Global Screen Tap Listener for Voice Assistant
  useEffect(() => {
    const handleScreenClick = (e) => {
      if (e.target.closest('button') || e.target.closest('input')) return;

      cancelSpeech();
      setIsListening(true);
      speakIn("Listening for your command...", 'en-US');

      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.onresult = (event) => {
          const speechResult = event.results[0][0].transcript;
          setLastCommand(speechResult);
          setIsListening(false);
          speakIn(`You said: ${speechResult}`, 'en-US');

          if (speechResult.toLowerCase().includes('user')) setActiveTab('users');
          if (speechResult.toLowerCase().includes('ocr')) setActiveTab('ocr');
          if (speechResult.toLowerCase().includes('currency')) setActiveTab('currency');
          if (speechResult.toLowerCase().includes('health')) setActiveTab('health');
          if (speechResult.toLowerCase().includes('logout')) handleLogout();
        };

        recognition.onerror = () => {
          setIsListening(false);
          speakIn("Could not hear clearly. Please try again.", 'en-US');
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        try {
          recognition.start();
        } catch (err) {
          setIsListening(false);
        }
      } else {
        setTimeout(() => {
          setIsListening(false);
          setLastCommand('Sample Voice Command Received');
          speakIn("Voice command received.", 'en-US');
        }, 2500);
      }
    };

    window.addEventListener('click', handleScreenClick);
    return () => window.removeEventListener('click', handleScreenClick);
  }, []);

  return (
    <div style={{ minHeight: '100vh', background: '#fffbeb', color: '#78350f', padding: '36px', fontFamily: "'Inter', sans-serif", boxSizing: 'border-box', position: 'relative' }}>
      
      {/* Listening Indicator Overlay */}
      {isListening && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(245, 158, 11, 0.3)', zIndex: 9999, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', backdropFilter: 'blur(4px)' }}>
          <div style={{ background: '#ffffff', padding: '40px 60px', borderRadius: '24px', boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2)', border: '4px solid #d97706', textAlign: 'center' }}>
            <Mic size={64} color="#d97706" style={{ animation: 'pulse 1.5s infinite', marginBottom: '20px' }} />
            <h2 style={{ fontSize: '32px', color: '#92400e', margin: '0 0 10px 0', fontWeight: '900' }}>Listening...</h2>
            <p style={{ fontSize: '20px', color: '#78350f', margin: 0, fontWeight: '600' }}>Speak your command now</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px', borderBottom: '2px solid rgba(217, 119, 6, 0.3)', paddingBottom: '24px' }}>
        <div>
          <div style={{ marginBottom: '12px' }}>
            <ProjectLogo size="medium" />
          </div>
          <h1 style={{ fontSize: '32px', color: '#92400e', margin: 0, fontWeight: '900' }}>Admin Dashboard</h1>
          <p style={{ fontSize: '18px', color: '#b45309', margin: '8px 0 0 0', fontWeight: '600' }}>Tap anywhere on screen to activate voice assistant</p>
          {lastCommand && <p style={{ fontSize: '15px', color: '#78350f', margin: '6px 0 0 0', fontWeight: '700' }}>Last Command: "{lastCommand}"</p>}
        </div>
        <button 
          onClick={handleLogout}
          style={{ background: '#fff', border: '2px solid #b91c1c', color: '#b91c1c', padding: '14px 24px', borderRadius: '12px', cursor: 'pointer', fontWeight: '800', fontSize: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}
        >
          <LogOut size={20} /> Logout
        </button>
      </div>

      {/* Navigation Tabs */}
      <div style={{ display: 'flex', gap: '16px', marginBottom: '32px', flexWrap: 'wrap' }}>
        {[
          { id: 'users', label: '👥 User Management' },
          { id: 'ocr', label: '👁️ OCR Document Reader' },
          { id: 'currency', label: '💵 Currency Recognition' },
          { id: 'voice', label: '🎙️ Voice & Assistant' },
          { id: 'health', label: '⚙️ System Health' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              padding: '18px 28px',
              borderRadius: '14px',
              border: activeTab === tab.id ? '3px solid #b45309' : '2px solid rgba(217, 119, 6, 0.4)',
              backgroundColor: activeTab === tab.id ? '#fde68a' : '#fef3c7',
              color: '#78350f',
              fontWeight: '800',
              fontSize: '18px',
              cursor: 'pointer',
              boxShadow: activeTab === tab.id ? '0 6px 12px rgba(180, 83, 9, 0.2)' : 'none'
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* USER MANAGEMENT TAB */}
      {activeTab === 'users' && (
        <div style={{ background: '#ffffff', padding: '36px', borderRadius: '20px', border: '2px solid rgba(217, 119, 6, 0.3)', boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.08)' }}>
          <h2 style={{ fontSize: '28px', color: '#92400e', marginBottom: '24px', fontWeight: '800' }}>Registered Platform Users</h2>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
            {users.map(user => (
              <div 
                key={user.id} 
                style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '24px', background: '#fffbeb', borderRadius: '14px', border: '2px solid rgba(217, 119, 6, 0.25)' }}
              >
                <div>
                  <h3 style={{ fontSize: '22px', fontWeight: '800', margin: '0 0 6px 0', color: '#78350f' }}>{user.name}</h3>
                  <p style={{ fontSize: '16px', color: '#92400e', margin: '0 0 10px 0', display: 'flex', alignItems: 'center', gap: '6px', fontWeight: '600' }}>
                    <Mail size={16} /> {user.email}
                  </p>
                  <span style={{ fontSize: '14px', padding: '4px 12px', borderRadius: '16px', background: 'rgba(217, 119, 6, 0.2)', color: '#b45309', fontWeight: '700' }}>
                    {user.role}
                  </span>
                </div>
                <button 
                  onClick={() => speakIn(`User selected: ${user.name}, role ${user.role}`, 'en-US')}
                  style={{ background: '#d97706', color: '#fff', border: 'none', padding: '12px 22px', borderRadius: '10px', fontSize: '16px', fontWeight: '800', cursor: 'pointer' }}
                >
                  Manage User
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* OCR DOCUMENT READER TAB */}
      {activeTab === 'ocr' && (
        <div style={{ background: '#ffffff', padding: '36px', borderRadius: '20px', border: '2px solid rgba(217, 119, 6, 0.3)', boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.08)' }}>
          <h2 style={{ fontSize: '28px', color: '#92400e', marginBottom: '16px', fontWeight: '800' }}>OCR Document Oversight</h2>
          <p style={{ fontSize: '20px', color: '#78350f', marginBottom: '24px', lineHeight: '1.5' }}>Monitor optical character recognition logs and text-to-speech requests across the platform.</p>
          <button 
            style={{ background: '#d97706', color: '#fff', border: 'none', padding: '16px 28px', borderRadius: '12px', fontWeight: '800', fontSize: '18px', cursor: 'pointer', boxShadow: '0 4px 8px rgba(217, 119, 6, 0.3)' }}
          >
            View OCR Logs
          </button>
        </div>
      )}

      {/* CURRENCY RECOGNITION TAB */}
      {activeTab === 'currency' && (
        <div style={{ background: '#ffffff', padding: '36px', borderRadius: '20px', border: '2px solid rgba(217, 119, 6, 0.3)', boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.08)' }}>
          <h2 style={{ fontSize: '28px', color: '#92400e', marginBottom: '16px', fontWeight: '800' }}>Currency Recognition Oversight</h2>
          <p style={{ fontSize: '20px', color: '#78350f', marginBottom: '24px', lineHeight: '1.5' }}>Review real-time currency detection accuracy, logs, and audio feedback telemetry for visually impaired users.</p>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '18px', marginBottom: '24px' }}>
            {currencyLogs.map(log => (
              <div 
                key={log.id} 
                style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 24px', background: '#fffbeb', borderRadius: '14px', border: '2px solid rgba(217, 119, 6, 0.25)' }}
              >
                <div>
                  <h3 style={{ fontSize: '20px', fontWeight: '800', margin: '0 0 6px 0', color: '#78350f', display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <DollarSign size={20} color="#b45309" /> {log.currency}
                  </h3>
                  <p style={{ fontSize: '15px', color: '#92400e', margin: 0, fontWeight: '600' }}>
                    Confidence: <strong style={{ color: '#b45309' }}>{log.confidence}</strong> • {log.timestamp}
                  </p>
                </div>
                <button 
                  onClick={() => speakIn(`Currency detected: ${log.currency} with ${log.confidence} confidence`, 'en-US')}
                  style={{ background: 'rgba(217, 119, 6, 0.15)', border: '2px solid #d97706', color: '#92400e', padding: '10px 18px', borderRadius: '10px', fontSize: '16px', fontWeight: '800', cursor: 'pointer' }}
                >
                  Test Audio Announce
                </button>
              </div>
            ))}
          </div>

          <button 
            onClick={() => speakIn("Currency recognition model calibration active.", 'en-US')}
            style={{ background: '#d97706', color: '#fff', border: 'none', padding: '16px 28px', borderRadius: '12px', fontWeight: '800', fontSize: '18px', cursor: 'pointer', boxShadow: '0 4px 8px rgba(217, 119, 6, 0.3)' }}
          >
            Calibrate Currency AI Model
          </button>
        </div>
      )}

      {/* VOICE & ASSISTANT TAB */}
      {activeTab === 'voice' && (
        <div style={{ background: '#ffffff', padding: '36px', borderRadius: '20px', border: '2px solid rgba(217, 119, 6, 0.3)', boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.08)' }}>
          <h2 style={{ fontSize: '28px', color: '#92400e', marginBottom: '16px', fontWeight: '800' }}>Voice Calling & Assistant Management</h2>
          <p style={{ fontSize: '20px', color: '#78350f', marginBottom: '24px', lineHeight: '1.5' }}>Configure speech synthesis parameters, microphone permissions, and voice assistant routing rules.</p>
        </div>
      )}

      {/* SYSTEM HEALTH TAB */}
      {activeTab === 'health' && (
        <div style={{ background: '#ffffff', padding: '36px', borderRadius: '20px', border: '2px solid rgba(217, 119, 6, 0.3)', boxShadow: '0 8px 16px -4px rgba(0, 0, 0, 0.08)' }}>
          <h2 style={{ fontSize: '28px', color: '#92400e', marginBottom: '16px', fontWeight: '800' }}>System Health & Diagnostics</h2>
          <p style={{ fontSize: '20px', color: '#78350f', marginBottom: '24px', lineHeight: '1.5' }}>All server nodes, database connections, and accessibility APIs are fully operational.</p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '18px', fontWeight: '700', color: '#15803d' }}>
            <ShieldCheck size={24} /> System Status: Online & Stable
          </div>
        </div>
      )}

    </div>
  );
}