import React, { useState, useEffect } from 'react';
import ProjectLogo from './ProjectLogo.jsx';
import { 
  Home, BookOpen, Calendar, Bell, 
  PlayCircle, Mic, MicOff, ArrowLeft, AlertCircle, Volume2, Award, Repeat, Keyboard, ChevronLeft, ChevronRight, Settings, Check, Trash2, Save, Clock, Bookmark, Sliders, Eye, Globe, BarChart2, TrendingUp, CheckCircle, XCircle, User 
} from 'lucide-react';

const getStudentProfile = () => {
  try {
    const session = JSON.parse(localStorage.getItem('auth_session') || '{}');
    const email = session.email || 'student@example.com';
    const name = email.split('@')[0].split(/[._-]+/).filter(Boolean).map(word => word[0].toUpperCase() + word.slice(1)).join(' ');
    return { name: name || 'Student', email };
  } catch { return { name: 'Student', email: 'student@example.com' }; }
};

export default function StudentDashboard() {
  const signedInStudent = getStudentProfile();
  const [selectedModule, setSelectedModule] = useState('exams'); 
  const [activeExam, setActiveExam] = useState(null); 
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [studentAnswer, setStudentAnswer] = useState('');
  const [examAnswers, setExamAnswers] = useState(() => JSON.parse(localStorage.getItem('student_exam_answers') || '{}'));
  const [examSubmitted, setExamSubmitted] = useState(false);
  
  // Question Status Tracking
  const [questionStatuses, setQuestionStatuses] = useState({});

  // Voice Mode vs Typing Mode Toggle State
  const [inputMode, setInputMode] = useState('voice'); 
  const [isRecording, setIsRecording] = useState(false);

  // Timer & AI Warnings State
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState(5720); // 01:35:20
  const [timerEnabled, setTimerEnabled] = useState(true);
  const [aiTimerWarningsEnabled, setAiTimerWarningsEnabled] = useState(true);

  // Accessibility Settings State
  const [accessibilitySettings, setAccessibilitySettings] = useState({
    voiceEnabled: true,
    speechSpeed: 0.8,
    volume: 80,
    voiceLanguage: 'en-US',
    fontSize: 'medium',
    highContrast: false,
    darkMode: false,
    largeButtons: false
  });

  // Language Selection State
  const [selectedLanguage, setSelectedLanguage] = useState('English');

  // Student Profile State
  const [studentProfile, setStudentProfile] = useState({
    name: signedInStudent.name,
    email: signedInStudent.email,
    phone: '+91 98765 43210',
    studentID: 'BCA-2026-042',
    preferredVoice: 'Natural Male (en-US)',
    accessibilityPreferences: 'Screen Reader Optimized, High Contrast Ready'
  });
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [tempProfile, setTempProfile] = useState({ ...studentProfile });

  // Notifications State
  const [notificationsList, setNotificationsList] = useState([
    {
      id: 'notif-1',
      type: 'Exam Starting',
      title: 'Exam Starting Soon',
      text: '🔔 Computer Networks exam starts in 30 minutes.',
      timestamp: '10 mins ago',
      read: false
    },
    {
      id: 'notif-2',
      type: 'New Exam',
      title: 'New Exam Notification',
      text: 'A new assessment for JavaScript Web Technologies has been scheduled.',
      timestamp: '2 hours ago',
      read: false
    },
    {
      id: 'notif-3',
      type: 'Exam Reminder',
      title: 'Exam Reminder',
      text: 'Reminder: Complete your pending Operating Systems pre-assessment check.',
      timestamp: '5 hours ago',
      read: false
    },
    {
      id: 'notif-4',
      type: 'Result',
      title: 'Result Published',
      text: 'Teacher released assessment results for Database Management Systems.',
      timestamp: 'Yesterday',
      read: true
    },
    {
      id: 'notif-5',
      type: 'Announcement',
      title: 'Teacher Announcement',
      text: 'Prof. Anderson uploaded additional study materials for subnet calculation.',
      timestamp: '2 days ago',
      read: true
    },
    {
      id: 'notif-6',
      type: 'Assistance',
      title: 'Assistance Response',
      text: 'Your voice query regarding OSI layer breakdown was successfully answered by AI Blind Assistant.',
      timestamp: '3 days ago',
      read: true
    }
  ]);

  // Results State with multiple subjects
  const [examResults, setExamResults] = useState([
    {
      id: 'res-1',
      examName: 'Computer Networks',
      subject: 'CNS',
      marksObtained: 78,
      totalMarks: 100,
      percentage: '78%',
      correct: 35,
      incorrect: 8,
      unanswered: 2,
      date: 'Sep 24, 2026',
      teacherFeedback: 'Good understanding of network routing and OSI layers. Work more on subnet calculations.'
    },
    {
      id: 'res-2',
      examName: 'Database Management Systems',
      subject: 'DBMS',
      marksObtained: 85,
      totalMarks: 100,
      percentage: '85%',
      correct: 40,
      incorrect: 5,
      unanswered: 0,
      date: 'Sep 18, 2026',
      teacherFeedback: 'Excellent normalization and SQL query performance.'
    },
    {
      id: 'res-3',
      examName: 'Web Technologies',
      subject: 'WEB',
      marksObtained: 42,
      totalMarks: 50,
      percentage: '84%',
      correct: 21,
      incorrect: 3,
      unanswered: 1,
      date: 'Sep 10, 2026',
      teacherFeedback: 'Great React component design and state handling.'
    }
  ]);

  const totalMarksObtainedAll = examResults.reduce((acc, curr) => acc + curr.marksObtained, 0);
  const totalPossibleMarksAll = examResults.reduce((acc, curr) => acc + curr.totalMarks, 0);
  const overallPercentageAll = ((totalMarksObtainedAll / totalPossibleMarksAll) * 100).toFixed(1);

  const [teacherConfig] = useState({
    enabledByTeacher: true,
    autoReadOnLoad: true,
    speechRate: 1.0,
  });

  const [voiceActive, setVoiceActive] = useState(false);
  const [voiceQuery, setVoiceQuery] = useState('');
  const [voiceFeedback, setVoiceFeedback] = useState('Voice Navigation ready. Say "Show profile", "Show notifications", "Show my results", etc.');

  const speakText = (textToSpeak) => {
    if (!accessibilitySettings.voiceEnabled || !teacherConfig.enabledByTeacher) {
      setVoiceFeedback('Text-to-Speech is currently disabled in Accessibility Settings.');
      return;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = accessibilitySettings.speechSpeed;
      utterance.lang = accessibilitySettings.voiceLanguage;
      utterance.onstart = () => setVoiceFeedback(`🔊 Speaking (${selectedLanguage}): "${textToSpeak}"`);
      window.speechSynthesis.speak(utterance);
    } else {
      setVoiceFeedback('Text-to-Speech is not supported in this browser.');
    }
  };

  useEffect(() => {
    localStorage.setItem('student_exam_answers', JSON.stringify(examAnswers));
  }, [examAnswers]);

  useEffect(() => {
    if (!activeExam || !timerEnabled || timeRemainingSeconds <= 0) return undefined;
    const timer = window.setInterval(() => setTimeRemainingSeconds(time => time - 1), 1000);
    return () => window.clearInterval(timer);
  }, [activeExam, timerEnabled, timeRemainingSeconds]);

  const formattedTime = `${String(Math.floor(timeRemainingSeconds / 3600)).padStart(2, '0')}:${String(Math.floor((timeRemainingSeconds % 3600) / 60)).padStart(2, '0')}:${String(timeRemainingSeconds % 60).padStart(2, '0')}`;
  const saveCurrentAnswer = () => {
    if (!activeExam) return;
    setExamAnswers(old => ({ ...old, [currentQuestionIndex]: studentAnswer }));
    setQuestionStatuses(old => ({ ...old, [currentQuestionIndex]: 'Answered' }));
    setVoiceFeedback('Answer auto-saved successfully.');
  };
  const recordVoiceAnswer = () => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) return setVoiceFeedback('Voice recognition is not supported in this browser. Use Google Chrome or type your answer.');
    const recognition = new Recognition();
    recognition.lang = accessibilitySettings.voiceLanguage;
    recognition.interimResults = false;
    recognition.onstart = () => { setIsRecording(true); setVoiceFeedback('Listening. Speak your answer now.'); };
    recognition.onresult = event => { const transcript = event.results[0][0].transcript; setStudentAnswer(answer => `${answer}${answer ? ' ' : ''}${transcript}`); setVoiceFeedback('Voice answer converted to text. Review it, then save.'); };
    recognition.onerror = () => setVoiceFeedback('Voice input could not be captured. Please try again or type your answer.');
    recognition.onend = () => setIsRecording(false);
    recognition.start();
  };
  const submitExam = () => { saveCurrentAnswer(); setExamSubmitted(true); setVoiceFeedback('Exam submitted successfully. Your teacher will review the responses.'); speakText('Your exam has been submitted successfully.'); };

  const processVoiceCommand = (commandText) => {
    const q = commandText.toLowerCase().trim();

    if (q.includes('show profile') || q.includes('profile')) {
      setSelectedModule('profile');
      setVoiceFeedback('Opening Student Profile module.');
      speakText('Opening Student Profile module.');
    } else if (q.includes('show notifications') || q.includes('notifications')) {
      setSelectedModule('notifications');
      setVoiceFeedback('Opening Notifications module.');
      speakText('Opening Notifications module.');
    } else if (q.includes('show my results') || q.includes('results')) {
      setSelectedModule('results');
      setVoiceFeedback('Opening My Results module.');
      speakText('Opening My Results module.');
    } else if (q.includes('go home') || q.includes('dashboard')) {
      setSelectedModule(null);
      setActiveExam(null);
      setVoiceFeedback('Returned to Student Home.');
      speakText('Returned to Student Home.');
    }
  };

  const handleGlobalVoiceSubmit = (e) => {
    e.preventDefault();
    if (!voiceQuery) return;
    processVoiceCommand(voiceQuery);
    setVoiceQuery('');
  };

  const dynamicContainerStyle = {
    minHeight: '100vh',
    fontFamily: 'Inter, system-ui, sans-serif',
    background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc',
    color: accessibilitySettings.darkMode ? '#f8fafc' : '#0f172a',
    filter: accessibilitySettings.highContrast ? 'contrast(135%)' : 'none',
    padding: '24px'
  };

  return (
    <div style={dynamicContainerStyle}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '16px 20px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <ProjectLogo size="medium" />
          <div>
            <h1 style={{ fontSize: '16px', fontWeight: 'bold', margin: 0, color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>Student Portal Dashboard</h1>
            <p style={{ fontSize: '12px', color: '#64748b', margin: '2px 0 0 0' }}>AI-Powered Blind Assistant & Accessible Assessment Portal</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button 
            onClick={() => {
              setVoiceActive(!voiceActive);
              speakText(voiceActive ? "Voice Navigation Deactivated" : "Voice Navigation Activated");
            }} 
            style={{ display: 'flex', alignItems: 'center', gap: '6px', background: voiceActive ? '#059669' : '#e11d48', color: '#fff', border: 'none', padding: '8px 14px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold' }}
          >
            <Mic size={18} /> {voiceActive ? 'Voice Assistant Active' : 'Voice Assistant Button'}
          </button>
        </div>
      </header>

      {/* Voice Navigation Command Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: accessibilitySettings.darkMode ? '#1e293b' : '#fff1f2', padding: '12px 16px', borderRadius: '10px', marginBottom: '20px', border: '1px solid #fecaca' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Volume2 color="#e11d48" size={22} />
          <div>
            <span style={{ fontSize: '11px', fontWeight: 'bold', color: '#e11d48' }}>VOICE NAVIGATION & SCREEN READER (Active Language: {selectedLanguage})</span>
            <p style={{ fontSize: '13px', color: accessibilitySettings.darkMode ? '#cbd5e1' : '#334155', margin: '2px 0 0 0' }}>{voiceFeedback}</p>
          </div>
        </div>
        <form onSubmit={handleGlobalVoiceSubmit} style={{ display: 'flex', gap: '8px', minWidth: '380px' }}>
          <input 
            type="text" 
            placeholder='Say "Show profile", "Show notifications", "Show my results"...' 
            value={voiceQuery}
            onChange={(e) => setVoiceQuery(e.target.value)}
            style={{ flex: 1, padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', outline: 'none', fontSize: '13px' }}
          />
          <button type="submit" style={{ background: '#e11d48', color: '#fff', border: 'none', padding: '8px 14px', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' }}>Run Voice</button>
        </form>
      </div>

      {selectedModule !== null && (
        <button onClick={() => setSelectedModule(null)} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'transparent', border: '1px solid #cbd5e1', padding: '8px 14px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a', marginBottom: '20px' }}>
          <ArrowLeft size={16} /> Back to Dashboard
        </button>
      )}

      {/* MODULE ROUTING */}
      {selectedModule === 'profile' ? (
        /* ================= STUDENT PROFILE MODULE ================= */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#ffffff', padding: '24px', borderRadius: '16px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)', border: '1px solid #e2e8f0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
              <div>
                <span style={{ background: '#eff6ff', color: '#2563eb', fontSize: '12px', fontWeight: 'bold', padding: '4px 10px', borderRadius: '20px', border: '1px solid #bfdbfe' }}>
                  👤 Student Profile Management
                </span>
                <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '8px 0 4px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>
                  Student Profile Details
                </h2>
                <p style={{ color: '#64748b', fontSize: '14px', margin: 0 }}>
                  Review and update your personal credentials, contact info, student ID, preferred voice, and accessibility preferences.
                </p>
              </div>
              <div style={{ display: 'flex', gap: '10px' }}>
                <button 
                  onClick={() => speakText(`Student Profile for ${studentProfile.name}. Student ID: ${studentProfile.studentID}. Email: ${studentProfile.email}. Phone: ${studentProfile.phone}. Preferred Voice: ${studentProfile.preferredVoice}. Accessibility Preferences: ${studentProfile.accessibilityPreferences}`)}
                  style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#0284c7', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
                >
                  <Volume2 size={18} /> Read Profile Aloud 🔊
                </button>
                {!isEditingProfile ? (
                  <button 
                    onClick={() => {
                      setTempProfile({ ...studentProfile });
                      setIsEditingProfile(true);
                    }}
                    style={{ background: '#e11d48', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
                  >
                    Edit Profile
                  </button>
                ) : (
                  <button 
                    onClick={() => {
                      setStudentProfile({ ...tempProfile });
                      setIsEditingProfile(false);
                      speakText("Profile updated successfully.");
                    }}
                    style={{ background: '#059669', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}
                  >
                    Save Changes
                  </button>
                )}
              </div>
            </div>

            <div style={{ marginTop: '24px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
              <div style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #cbd5e1' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#64748b', display: 'block', marginBottom: '6px' }}>• Name</label>
                {isEditingProfile ? (
                  <input type="text" value={tempProfile.name} onChange={(e) => setTempProfile({ ...tempProfile, name: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px' }} />
                ) : (
                  <p style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>{studentProfile.name}</p>
                )}
              </div>

              <div style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #cbd5e1' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#64748b', display: 'block', marginBottom: '6px' }}>• Email</label>
                {isEditingProfile ? (
                  <input type="email" value={tempProfile.email} onChange={(e) => setTempProfile({ ...tempProfile, email: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px' }} />
                ) : (
                  <p style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>{studentProfile.email}</p>
                )}
              </div>

              <div style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #cbd5e1' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#64748b', display: 'block', marginBottom: '6px' }}>• Phone</label>
                {isEditingProfile ? (
                  <input type="text" value={tempProfile.phone} onChange={(e) => setTempProfile({ ...tempProfile, phone: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px' }} />
                ) : (
                  <p style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>{studentProfile.phone}</p>
                )}
              </div>

              <div style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #cbd5e1' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#64748b', display: 'block', marginBottom: '6px' }}>• Student ID</label>
                {isEditingProfile ? (
                  <input type="text" value={tempProfile.studentID} onChange={(e) => setTempProfile({ ...tempProfile, studentID: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px' }} />
                ) : (
                  <p style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>{studentProfile.studentID}</p>
                )}
              </div>

              <div style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #cbd5e1' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#64748b', display: 'block', marginBottom: '6px' }}>• Preferred Voice</label>
                {isEditingProfile ? (
                  <select value={tempProfile.preferredVoice} onChange={(e) => setTempProfile({ ...tempProfile, preferredVoice: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px' }}>
                    <option value="Natural Male (en-US)">Natural Male (en-US)</option>
                    <option value="Natural Female (en-US)">Natural Female (en-US)</option>
                    <option value="British English (en-GB)">British English (en-GB)</option>
                    <option value="Indian English (en-IN)">Indian English (en-IN)</option>
                  </select>
                ) : (
                  <p style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>{studentProfile.preferredVoice}</p>
                )}
              </div>

              <div style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #cbd5e1' }}>
                <label style={{ fontSize: '12px', fontWeight: 'bold', color: '#64748b', display: 'block', marginBottom: '6px' }}>• Accessibility Preferences</label>
                {isEditingProfile ? (
                  <input type="text" value={tempProfile.accessibilityPreferences} onChange={(e) => setTempProfile({ ...tempProfile, accessibilityPreferences: e.target.value })} style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px' }} />
                ) : (
                  <p style={{ fontSize: '16px', fontWeight: 'bold', margin: 0 }}>{studentProfile.accessibilityPreferences}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : selectedModule === 'notifications' ? (
        /* ================= NOTIFICATIONS MODULE ================= */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#ffffff', padding: '24px', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ background: '#fef3c7', color: '#d97706', fontSize: '12px', fontWeight: 'bold', padding: '4px 10px', borderRadius: '20px' }}>🔔 Notifications Center</span>
                <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '8px 0 4px 0' }}>Student Notifications & Alerts</h2>
              </div>
              <button onClick={() => speakText(`You have ${notificationsList.filter(n => !n.read).length} unread notifications.`)} style={{ background: '#d97706', color: '#fff', border: 'none', padding: '10px 16px', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' }}>
                <Volume2 size={18} /> Read Aloud
              </button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '20px' }}>
              {notificationsList.map(n => (
                <div key={n.id} style={{ background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', padding: '16px', borderRadius: '10px', borderLeft: n.read ? '4px solid #cbd5e1' : '4px solid #e11d48' }}>
                  <h4 style={{ margin: '0 0 4px 0', fontSize: '15px' }}>{n.title}</h4>
                  <p style={{ margin: 0, fontSize: '13px', color: '#64748b' }}>{n.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : selectedModule === 'results' ? (
        /* ================= MY RESULTS MODULE ================= */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#ffffff', padding: '24px', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0 0 8px 0' }}>My Results & Assessment Performance</h2>
            <p style={{ color: '#64748b', fontSize: '14px' }}>Overall cumulative percentage across all subjects: <strong>{overallPercentageAll}%</strong></p>
          </div>
        </div>
      ) : selectedModule === 'accessibility' ? (
        /* ================= ACCESSIBILITY SETTINGS MODULE ================= */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#ffffff', padding: '24px', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0 0 8px 0' }}>Accessibility & Screen Reader Settings</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '16px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '14px', cursor: 'pointer' }}>
                <input type="checkbox" checked={accessibilitySettings.darkMode} onChange={(e) => setAccessibilitySettings({...accessibilitySettings, darkMode: e.target.checked})} />
                Enable Dark Mode
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '14px', cursor: 'pointer' }}>
                <input type="checkbox" checked={accessibilitySettings.highContrast} onChange={(e) => setAccessibilitySettings({...accessibilitySettings, highContrast: e.target.checked})} />
                High Contrast Mode
              </label>
            </div>
          </div>
        </div>
      ) : selectedModule === 'language' ? (
        /* ================= LANGUAGE SELECTION MODULE ================= */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#ffffff', padding: '24px', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0 0 8px 0' }}>Language Selection</h2>
            <p style={{ color: '#64748b', fontSize: '14px' }}>Active Language: {selectedLanguage}</p>
          </div>
        </div>
      ) : selectedModule === 'home' || selectedModule === 'exams' ? (
        /* ================= STUDENT HOME & EXAMS ================= */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#ffffff', padding: '24px', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0 0 8px 0' }}>My Accessible Exams</h2>
            <p style={{ color: '#64748b', fontSize: '14px' }}>Use audio controls, voice answers, keyboard input, review marking, and assistance during each assessment.</p>
            {[
              { title: 'Computer Networks Assessment', subject: 'Computer Science', date: 'Today · 10:00 AM', duration: '120 minutes', status: 'Ready to start' },
              { title: 'Web Development Quiz', subject: 'Web Technology', date: '02 Oct · 11:30 AM', duration: '30 minutes', status: 'Scheduled' },
            ].map(exam => (
              <div key={exam.title} style={{ marginTop: '16px', padding: '16px', borderRadius: '10px', background: accessibilitySettings.darkMode ? '#0f172a' : '#f8fafc', border: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                <div><h3 style={{ margin: 0, fontSize: '16px' }}>{exam.title}</h3><p style={{ margin: '5px 0', color: '#64748b', fontSize: '13px' }}>{exam.subject} · {exam.date} · {exam.duration}</p><span style={{ color: '#059669', fontWeight: 'bold', fontSize: '12px' }}>{exam.status}</span></div>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}><button onClick={() => speakText(`${exam.title}. ${exam.subject}. ${exam.date}. Duration ${exam.duration}.`)} style={{ border: '1px solid #0284c7', color: '#0284c7', background: '#fff', padding: '9px 12px', borderRadius: '7px', cursor: 'pointer' }}><Volume2 size={16}/> Read</button><button onClick={() => { setActiveExam(exam); setCurrentQuestionIndex(0); setStudentAnswer(''); setVoiceFeedback(`Exam started: ${exam.title}`); speakText(`Starting ${exam.title}. Question one is ready.`); }} style={{ background: '#e11d48', color: '#fff', border: 0, padding: '9px 12px', borderRadius: '7px', cursor: 'pointer', fontWeight: 'bold' }}>Start / Resume</button></div>
              </div>
            ))}
            {activeExam && <div style={{ marginTop: '20px', padding: '18px', background: accessibilitySettings.darkMode ? '#0f172a' : '#eff6ff', borderRadius: '10px', border: '1px solid #bfdbfe' }}><b>Active exam: {activeExam.title}</b><p style={{ fontSize: '13px', color: '#475569' }}>Question {currentQuestionIndex + 1} of 20 · Time remaining: 01:42:15</p><textarea value={studentAnswer} onChange={e => setStudentAnswer(e.target.value)} placeholder="Type your answer or use voice input" style={{ width: '100%', minHeight: '90px', padding: '10px', border: '1px solid #cbd5e1', borderRadius: '8px' }}/><div style={{ display: 'flex', gap: '8px', marginTop: '12px', flexWrap: 'wrap' }}><button onClick={() => speakText('Question number ' + (currentQuestionIndex + 1))} style={{ padding: '9px 12px', border: 0, borderRadius: '7px', background: '#0284c7', color: '#fff' }}>🔊 Read question</button><button onClick={() => setQuestionStatuses({...questionStatuses,[currentQuestionIndex]:'Review'})} style={{ padding: '9px 12px', border: '1px solid #f59e0b', borderRadius: '7px', background: '#fff', color: '#b45309' }}>Mark for review</button><button onClick={() => { setQuestionStatuses({...questionStatuses,[currentQuestionIndex]:'Answered'}); setCurrentQuestionIndex(i => Math.min(19,i+1)); setStudentAnswer(''); setVoiceFeedback('Answer auto-saved. Next question opened.'); }} style={{ padding: '9px 12px', border: 0, borderRadius: '7px', background: '#059669', color: '#fff' }}>Save & next</button><button onClick={() => setVoiceFeedback('SOS request sent to your teacher.')} style={{ padding: '9px 12px', border: 0, borderRadius: '7px', background: '#dc2626', color: '#fff' }}>SOS Request assistance</button></div></div>}
          </div>
        </div>
      ) : (
        /* ================= DEFAULT DASHBOARD GRID CARDS (All 6 Features) ================= */
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '20px' }}>
          
          <div onClick={() => setSelectedModule('profile')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#eff6ff', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <User size={22} color="#2563eb" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>Student Profile ⭐</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>Manage name, email, phone, student ID, preferred voice, and accessibility preferences.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#2563eb' }}>Open Student Profile →</span>
          </div>

          <div onClick={() => setSelectedModule('home')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#ffe4e6', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <Home size={22} color="#e11d48" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>Student Home ⭐</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>View welcome message, today's exams, upcoming exams, completed exams, and quick voice launcher.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#e11d48' }}>Open Student Home →</span>
          </div>

          <div onClick={() => setSelectedModule('exams')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#e0f2fe', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <BookOpen size={22} color="#0284c7" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>My Exams</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>Connected with teacher's assessment assistant. View exam subjects, dates, status, and instructions.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#0284c7' }}>Open My Exams →</span>
          </div>

          <div onClick={() => setSelectedModule('results')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#d1fae5', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <BarChart2 size={22} color="#059669" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>My Results ⭐</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>View all subjects, cumulative percentage, exam history, subject breakdown, and teacher feedback.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#059669' }}>Open My Results →</span>
          </div>

          <div onClick={() => setSelectedModule('notifications')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <Bell size={22} color="#d97706" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>Notifications ⭐</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>View new exam alerts, exam starting notices, reminders, published results, and teacher announcements.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#d97706' }}>Open Notifications →</span>
          </div>

          <div onClick={() => setSelectedModule('accessibility')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#f3e8ff', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <Sliders size={22} color="#9333ea" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>Accessibility Settings</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>Customize screen reader speed, high contrast, dark mode, and speech parameters.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#9333ea' }}>Open Accessibility Settings →</span>
          </div>

          <div onClick={() => setSelectedModule('language')} style={{ background: accessibilitySettings.darkMode ? '#1e293b' : '#fff', padding: '24px', borderRadius: '16px', cursor: 'pointer', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: '#ccfbf1', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
              <Globe size={22} color="#0d9488" />
            </div>
            <h3 style={{ fontSize: '16px', fontWeight: 'bold', margin: '0 0 8px 0', color: accessibilitySettings.darkMode ? '#fff' : '#0f172a' }}>Language Selection</h3>
            <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px 0', lineHeight: '1.4' }}>Multilingual support for English, Kannada, Hindi, Malayalam, Tamil, Telugu.</p>
            <span style={{ fontSize: '13px', fontWeight: 'bold', color: '#0d9488' }}>Open Language Selection →</span>
          </div>

        </div>
      )}

    </div>
  );
}
