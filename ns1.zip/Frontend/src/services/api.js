const API_BASE_URL = 'http://localhost:5000/api';

// Fetch recent activity logs
export const fetchLogs = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/logs`);
    const data = await response.json();
    if (data.success) {
      return data.data;
    }
    throw new Error(data.error || 'Failed to fetch logs');
  } catch (error) {
    console.error('Error fetching logs:', error);
    return [];
  }
};

// Save a new question and answer
export const saveQuestion = async (questionData) => {
  try {
    const response = await fetch(`${API_BASE_URL}/questions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(questionData),
    });
    const data = await response.json();
    if (data.success) {
      return data.data;
    }
    throw new Error(data.error || 'Failed to save question');
  } catch (error) {
    console.error('Error saving question:', error);
    throw error;
  }
};

// Teacher Exam Assistant API helpers
export const fetchExams = async () => {
  const response = await fetch(`${API_BASE_URL}/exams`);
  if (!response.ok) throw new Error('Unable to load exams');
  const body = await response.json();
  return body.data || body;
};

export const createExam = async (exam) => {
  const payload = {
    title: exam.title,
    subject: exam.subject,
    durationMinutes: Number(exam.duration || exam.durationMinutes || 60),
    date: exam.date,
    startTime: exam.time || exam.startTime,
    passingMarks: Number(exam.passMark || exam.passingMarks || 40),
    instructions: exam.instructions,
    accessibilitySettings: exam.accessibilitySettings || {},
    assignedStudents: exam.assignedStudents || [],
    questions: (exam.questions || []).map((question, index) => ({
      questionNumber: index + 1,
      questionText: question.text || question.questionText,
      questionType: question.type || question.questionType || 'MCQ',
      marks: Number(question.marks || 1),
      difficulty: question.difficulty || 'Medium',
      options: Array.isArray(question.options) ? question.options : [],
      correctAnswer: question.correctAnswer || question.answer || 'To be reviewed by teacher',
    })),
  };
  const response = await fetch(`${API_BASE_URL}/exams`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Unable to save exam');
  return body.data || body;
};

export const updateExam = async (examId, updates) => {
  const response = await fetch(`${API_BASE_URL}/exams/${examId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Unable to update exam');
  return body.data || body;
};

export const deleteExam = async (examId) => {
  const response = await fetch(`${API_BASE_URL}/exams/${examId}`, { method: 'DELETE' });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Unable to delete exam');
  return body;
};

export const fetchResults = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/results`);
    if (!response.ok) throw new Error('Unable to fetch results');
    const body = await response.json();
    return body.data || [];
  } catch (error) {
    console.error('Error fetching results:', error);
    return [];
  }
};

export const generateDraftQuestions = async ({ topic, count, difficulty }) => {
  try {
    const response = await fetch(`${API_BASE_URL}/ai/generate-questions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic, count, difficulty }),
    });
    const body = await response.json();
    if (response.ok && body.success && Array.isArray(body.data)) {
      return body.data;
    }
  } catch (e) {
    console.warn('Backend AI endpoint unavailable, using frontend draft generator');
  }

  // Fallback generation if backend offline
  return Array.from({ length: Math.max(1, Number(count) || 1) }, (_, index) => {
    const isMcq = index % 2 === 0;
    return {
      id: `ai-${Date.now()}-${index + 1}`,
      text: `[${topic}] Question ${index + 1}: Describe the key principles and accessibility implications.`,
      type: isMcq ? 'MCQ' : 'Short answer',
      marks: isMcq ? 2 : 5,
      difficulty: difficulty || 'Medium',
      options: isMcq ? ['Option A: Accessibility First', 'Option B: Standard Access', 'Option C: Offline Mode', 'Option D: None'] : [],
      correctAnswer: isMcq ? 'Option A: Accessibility First' : 'Clear structured response.',
      ai: true,
    };
  });
};
