// Frontend/src/services/elevenlabs.js - ElevenLabs TTS & AI Voice Assistant Service

export const ELEVENLABS_VOICES = [
  { id: '21m00Tcm4TlvDq8ikWAM', name: 'Rachel (Calm & Clear)', gender: 'Female', description: 'Best for blind student instructions' },
  { id: 'EXAVITQu4vr4xnSDxMaL', name: 'Bella (Soft & Friendly)', gender: 'Female', description: 'Warm natural reading tone' },
  { id: 'ErXwobaYiN019PkySvjV', name: 'Antoni (Smooth & Well-spoken)', gender: 'Male', description: 'Clear enunciated male voice' },
  { id: 'pNInz6obpgDQGcFmaJgB', name: 'Adam (Deep & Professional)', gender: 'Male', description: 'Deep clear narration' },
  { id: 'AZnzlk1XvdvUeBnXmlld', name: 'Domi (Energetic & Direct)', gender: 'Female', description: 'Clear distinct voice' }
];

let currentAudio = null;

export const getElevenLabsConfig = () => {
  return {
    apiKey: localStorage.getItem('elevenlabs_api_key') || '',
    voiceId: localStorage.getItem('elevenlabs_voice_id') || '21m00Tcm4TlvDq8ikWAM',
    stability: Number(localStorage.getItem('elevenlabs_stability')) || 0.65,
    similarityBoost: Number(localStorage.getItem('elevenlabs_similarity')) || 0.85,
    enabled: localStorage.getItem('elevenlabs_enabled') !== 'false' // Enabled by default
  };
};

export const saveElevenLabsConfig = (config) => {
  if (config.apiKey !== undefined) localStorage.setItem('elevenlabs_api_key', config.apiKey);
  if (config.voiceId !== undefined) localStorage.setItem('elevenlabs_voice_id', config.voiceId);
  if (config.stability !== undefined) localStorage.setItem('elevenlabs_stability', config.stability);
  if (config.similarityBoost !== undefined) localStorage.setItem('elevenlabs_similarity', config.similarityBoost);
  if (config.enabled !== undefined) localStorage.setItem('elevenlabs_enabled', config.enabled ? 'true' : 'false');
};

export const cancelElevenLabsSpeech = () => {
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.currentTime = 0;
    } catch (e) {}
    currentAudio = null;
  }
};

export const speakWithElevenLabs = async (text, options = {}) => {
  // Cancel any ongoing audio
  cancelElevenLabsSpeech();

  const config = getElevenLabsConfig();
  const cleanedText = String(text || '')
    .replace(/@/g, ' at ')
    .replace(/\bvs\b/gi, ' versus ')
    .replace(/\b(etc\.)\b/gi, ' et cetera ')
    .replace(/\b(e\.g\.)\b/gi, ' for example ')
    .replace(/[\/\-_]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!cleanedText) {
    if (options.onEnd) options.onEnd();
    return false;
  }

  // If user disabled ElevenLabs, skip to fallback
  if (!config.enabled) {
    return false;
  }

  try {
    let audioBlobUrl = null;

    // Try Backend Proxy first
    try {
      const response = await fetch('http://localhost:5000/api/tts/speak', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleanedText,
          voiceId: options.voiceId || config.voiceId,
          apiKey: config.apiKey,
          stability: config.stability,
          similarityBoost: config.similarityBoost
        })
      });

      if (response.ok) {
        const blob = await response.blob();
        audioBlobUrl = URL.createObjectURL(blob);
      }
    } catch (backendError) {
      console.warn('Backend ElevenLabs proxy unavailable, trying direct API call if key is present...');
    }

    // Direct ElevenLabs API Fallback if key is present locally
    if (!audioBlobUrl && config.apiKey) {
      const directRes = await fetch(
        `https://api.elevenlabs.io/v1/text-to-speech/${options.voiceId || config.voiceId}`,
        {
          method: 'POST',
          headers: {
            'xi-api-key': config.apiKey,
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg'
          },
          body: JSON.stringify({
            text: cleanedText,
            model_id: 'eleven_multilingual_v2',
            voice_settings: {
              stability: config.stability,
              similarity_boost: config.similarityBoost
            }
          })
        }
      );

      if (directRes.ok) {
        const blob = await directRes.blob();
        audioBlobUrl = URL.createObjectURL(blob);
      }
    }

    if (audioBlobUrl) {
      const audio = new Audio(audioBlobUrl);
      currentAudio = audio;

      audio.onended = () => {
        currentAudio = null;
        if (options.onEnd) options.onEnd();
      };

      audio.onerror = (e) => {
        console.error('ElevenLabs Audio playback error:', e);
        currentAudio = null;
        if (options.onEnd) options.onEnd();
      };

      await audio.play();
      return true; // Successfully spoke via ElevenLabs
    }
  } catch (err) {
    console.warn('ElevenLabs TTS playback fallback:', err);
  }

  return false; // Failed or no key, caller can use browser SpeechSynthesis fallback
};
